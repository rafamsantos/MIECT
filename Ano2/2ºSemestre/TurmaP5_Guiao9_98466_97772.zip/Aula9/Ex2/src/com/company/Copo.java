package com.company;

public class Copo extends DecoradorGelados{

    private Gelado g;

    public Copo(Gelado g) {
        super(g);
    }
    public void base(int i){
        g.base(i);
        System.out.print(" em copo");
    }
}
