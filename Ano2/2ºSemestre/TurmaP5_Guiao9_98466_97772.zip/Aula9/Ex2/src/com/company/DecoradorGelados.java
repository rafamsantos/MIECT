package com.company;

public class DecoradorGelados implements Gelado {
    private Gelado g;
    public DecoradorGelados(Gelado g){
        this.g = g;
    }
    public void base(int i){
        g.base(i);
    }
}
