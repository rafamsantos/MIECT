package com.company;

public class Cone extends DecoradorGelados{
    private static Gelado g;
    public Cone(Gelado g){
        super(g);
    }
    public void base(int i){
        g.base(i);
        System.out.print(" em cone");
    }
}
