package com.company;

public class GeladoSimples implements Gelado {
    private static String ingrediente;

    public GeladoSimples(String ingrediente){
        this.ingrediente = ingrediente;
    }
    public void base(int i){
        if(i ==1) System.out.printf(i + " bola de gelado de : " + ingrediente);
        else System.out.println(i + " bolas de gelado de : " + ingrediente);
    }
}
