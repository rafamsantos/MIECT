package com.company;

public class Topping extends DecoradorGelados{
    private static Gelado g;
    private static String topping;

    public Topping(Gelado g , String topping){
        super(g);
        this.topping = topping;

    }
    public String topping(String topping){ return topping;}
    public void base(int i){
        g.base(i);
        System.out.print(" com topping " + topping);
    }
}
