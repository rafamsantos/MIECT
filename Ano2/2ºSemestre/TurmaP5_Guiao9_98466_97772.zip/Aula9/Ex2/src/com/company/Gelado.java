package com.company;

public interface Gelado {
    void base(int i);
}
