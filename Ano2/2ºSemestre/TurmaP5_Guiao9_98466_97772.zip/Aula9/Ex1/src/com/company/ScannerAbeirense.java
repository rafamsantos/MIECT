package com.company;

import java.io.Closeable;
import java.io.IOException;
import java.util.Iterator;
import java.util.function.Consumer;
import java.util.Scanner;
import java.io.*;

public class ScannerAbeirense implements Iterator<String>, Closeable {
    Scanner ler;

    public ScannerAbeirense(){
        ler = new Scanner(System.in);
    }
    public ScannerAbeirense(File file)throws IOException{
        ler = new Scanner(file);
    }
    @Override
    public void close() throws IOException{
        ler.close();
    }

    @Override
    public boolean hasNext() {
        if(ler.hasNext()) return true;
        else return false;
    }

    @Override
    public String next() {
        String original = ler.next();
        String alterada = original.replaceAll("v" , "b");
        alterada = alterada.replaceAll("V", "B");
        return alterada;
    }
}
