package com.company;
import java.util.Scanner;
import java.io.*;

public class Main {

    public static void main(String[] args) throws IOException {

        // Teste com ficheiro
        System.out.println("\nTeste de um ficheiro\n");
        File f = new File("C:/Users/rafa_/Desktop/IdeaProjects/Programação3/Aula9/Ex1/P3.txt");
        ScannerAbeirense fab = new ScannerAbeirense(f);
        while(fab.hasNext())
            System.out.println(fab.next());
        fab.close();

        // Teste lendo do teclado
        ScannerAbeirense sa = new ScannerAbeirense();
        System.out.println("Teste através do teclado : ");
        System.out.println("Insira uma frase : ");
        String frase = sa.next();
        System.out.println(frase);


    }
}
