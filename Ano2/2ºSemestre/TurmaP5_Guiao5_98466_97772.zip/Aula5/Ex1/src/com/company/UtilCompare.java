package com.company;
import java.util.Arrays;

public class UtilCompare {

    public static <T> Comparable<T> findMax(Comparable<T>[]a){
        int maxIndex = 0;

        for(int i = 1 ; i <a.length ; i++){
            if(a[i] != null && a[i].compareTo((T) a[maxIndex]) > 0){
                maxIndex = i;
            }
        }
        return a[maxIndex];
    }
    public static <T> void sortArray(Comparable<T>[]a){
        for(int i = 0; i <a.length ; i++){
            for(int j = i ; i < a.length ; i++){
                if((a[i].compareTo((T)a[j]))>0){
                    Comparable<T> tmp = a[i];
                    a[i]= a[j];
                    a[j]= tmp;
                }
            }
        }
    }
}
