package com.company;

public class vCard {

    public static void readFile(String fich){}
}
