package com.company;

public abstract class Figura implements Comparable<Figura> {
    protected Ponto centro;

    public Figura() {
        this.centro = new Ponto();
    }

    public Figura(Ponto center) {
        this.centro = center;
    }

    public Figura(double x, double y) {
        this.centro = new Ponto(x, y);
    }

    public Figura(Figura other) {
        this.centro = other.centro;
    }

    public Ponto getCentro() {
        return centro;
    }

    public void setCentro(Ponto centro) {
        this.centro = centro;
    }


    public abstract double area();


    public abstract double perimetro();


    public int compareTo(Figura arg0) {
        return -1;
    }

    public boolean equals(Object obj) {
        try {
            return this.centro.equals(this.getClass().cast(obj).getCentro());
        } catch (ClassCastException ex) {
            return super.equals(obj);
        }
    }

    @Override
    public String toString() {
        return String.format("\"Figure\": {\"center\": %s, \"area\": %.2f, \"perimeter\": %.2f}", this.centro, area(), perimetro());
    }
}
