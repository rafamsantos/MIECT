package com.company;

import java.util.*;

public class ColecaoFigura {
    private Set<Figura> figures;
    private double maxArea;

    public ColecaoFigura(double maxArea) {
        this.figures = new HashSet<>();
        this.maxArea = maxArea;
    }

    public double getMaxArea() {
        return maxArea;
    }

    public boolean exists(Figura f) {
        return this.figures.contains(f);
    }

    public Figura[] gatFiguras() {
        return figures.toArray(new Figura[figures.size()]);
    }

    public Ponto[] getCenters() {
        Set<Ponto> centros = new HashSet<>();

        for (Figura f : figures) {
            centros.add(f.getCentro());
        }

        return centros.toArray(new Ponto[centros.size()]);
    }

    public boolean addFigure(Figura f) {
        return ((totalArea() + f.area()) <= maxArea) ? figures.add(f) : false;
    }

    public boolean delFigure(Figura f) {
        return figures.remove(f);
    }

    public double totalArea() {
        double totalArea = 0;

        for (Figura f : this.figures) {
            totalArea += f.area();
        }

        return totalArea;
    }

    @Override
    public String toString() {
        return String.format("\"FigureCollection\": {\"maxArea\": %.2f, \"totalArea\": %.2f, \"Figures\": %s }",
                this.maxArea, this.totalArea(), Arrays.toString(this.gatFiguras())
        );
    }
}

