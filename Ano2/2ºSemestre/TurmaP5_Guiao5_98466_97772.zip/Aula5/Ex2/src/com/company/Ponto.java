package com.company;

public final class Ponto {
    public final double x, y;

    public Ponto() {
        this.x = 0; this.y = 0;
    }

    public Ponto(Ponto other) {
        this.x = other.x;
        this.y = other.y;
    }

    public Ponto(double x, double y) {
        this.x = x; this.y = y;
    }

    public Ponto halfWayTo(Ponto point) {
        return new Ponto((this.x + point.x)/2.0,(this.y + point.y)/2.0);
    }

    public double distanceTo(Ponto point) {
        return Math.sqrt(Math.pow(this.x-point.x,2) + Math.pow(this.y-point.y,2));
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Ponto) {
            Ponto other = this.getClass().cast(obj);
            return this.x == other.x && this.y == other.y;
        } else {
            return super.equals(obj);
        }
    }

    @Override
    public String toString() {
        return String.format("(%.2f, %.2f)", x, y);
    }

    public static Ponto soma(Ponto p1, Ponto p2) {
        return new Ponto(p1.x + p2.x, p1.y + p2.y);
    }

    public static Ponto subetrair(Ponto p1, Ponto p2) {
        return new Ponto(p1.x - p2.x, p1.y - p2.y);
    }
}

