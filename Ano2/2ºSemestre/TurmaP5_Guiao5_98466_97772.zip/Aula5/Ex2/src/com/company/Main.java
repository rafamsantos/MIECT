package com.company;

public class Main {

    public static void main(String[] args) {
        Circulo c1 = new Circulo(2);
        Circulo c2 = new Circulo(1, 3, 2);
        Square q1 = new Square(2);
        Square q2 = new Square(3, 4, 2);
        Retangulo r1 = new Retangulo(2, 3);
        Retangulo r2 = new Retangulo(3, 4, 2, 3);
        ColecaoFigura col = new ColecaoFigura(42.0);//MaxArea

        System.out.println(col.addFigure(c2));// true
        System.out.println(col.addFigure(r1));// true
        System.out.println(col.addFigure(r1));// false
        System.out.println(col.addFigure(r2));// true
        System.out.println(col.addFigure(c1));// true
        System.out.println(col.addFigure(q2));// true
        System.out.println(col.addFigure(q1));// false
        System.out.println(col.delFigure(r1));// true
        System.out.println(col.addFigure(q1));// true
        System.out.println("\nÁrea Total da Lista de Figures: " + col.totalArea());

        Figura[] listaFig = col.gatFiguras();

        System.out.println("\nLista de Figures:");
        for (Figura f: listaFig)
            System.out.println(f);

        System.out.println("\nComparacao da area do primeiro elemento com todos");
        for (int i = 0; i < listaFig.length; i++) {
            System.out.printf("%2d %12s de area %6.2f compareTo(listaFig[0]) = %2d\n", i,
                    listaFig[i].getClass().getSimpleName(),
                    listaFig[i].area(),
                    listaFig[i].compareTo(listaFig[0]));
        }

        System.out.println("\nFigure com maior Area: " + UtilCompare.findMax(listaFig) );
        // Ordena (crescente) o array de Figures por areas
        UtilCompare.sortArray(listaFig);

        System.out.println ("\nLista de Figures Ordenadas por Area:");
        for (Figura f: listaFig)
            System.out.println (f + " -> area: " + String.format("%2.2f", f.area()) +
                    " e perimetro: " + String.format("%2.2f", f.perimetro()));
    }

}
