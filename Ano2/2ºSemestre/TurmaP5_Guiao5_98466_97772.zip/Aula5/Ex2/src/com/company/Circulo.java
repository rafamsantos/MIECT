package com.company;

public class Circulo extends Figura {
    private double raio;

    public Circulo() {
        super();
        this.raio = 0;
    }

    public Circulo(double r) {
        super();
        this.raio = r;
    }

    public Circulo(Ponto center) {
        super(center);
        this.raio = 0;
    }

    public Circulo(Ponto center, double r) {
        super(center);
        this.raio = r;
    }

    public Circulo(Ponto center, Ponto r) {
        super(center);
        this.raio = center.distanceTo(r);
    }

    public Circulo(double x, double y, double r) {
        super(x, y);
        this.raio = r;
    }

    public Circulo(Figura other) {
        super(other);
        this.raio = 0;
    }

    public Circulo(Figura other, double r) {
        super(other);
        this.raio = r;
    }

    public Circulo(Circulo other) {
        super(other);
        this.raio = other.raio;
    }

    public double getRaio() {
        return raio;
    }

    public void setRaio(double raio) {
        this.raio = raio;
    }

    public boolean interceta(Circulo circle) {
        return centro.distanceTo(circle.centro) <= (raio + circle.raio);
    }


    public int compareTo(Figura arg0) {
        try {
            Circulo a = this.getClass().cast(arg0);
            return (int)(this.area() - a.area());
        } catch (ClassCastException ex) {
            return super.compareTo(arg0);
        }
    }


    public double area() {
        return Math.PI * Math.pow(raio, 2);
    }


    public double perimetro() {
        return 2 * Math.PI * raio;
    }


    public boolean equals(Object obj) {
        try {
            Circulo a = this.getClass().cast(obj);
            return super.equals(obj)
                    && this.raio == a.raio
                    && this.area() == a.area()
                    && this.perimetro() == a.perimetro();
        } catch (ClassCastException ex) {
            return super.equals(obj);
        }
    }


    public String toString() {
        return String.format("\"Circle\": {%s, \"radius\": %.2f}", super.toString(), this.raio);
    }
}
