package com.company;

public class Square extends Figura {
    private double side;

    public Square() {
        super();
        this.side = 0;
    }

    public Square(Ponto center) {
        super(center);
        this.side = 0;
    }

    public Square(double side) {
        super();
        this.side = side;
    }

    public Square(Ponto center, double side) {
        super(center);
        this.side = side;
    }

    public Square(double x, double y) {
        super(x, y);
        this.side = 0;
    }

    public Square(double x, double y, double side) {
        super(x, y);
        this.side = side;
    }

    public Square(Figura other) {
        super(other);
        this.side = 0;
    }

    public Square(Figura other, double side) {
        super(other);
        this.side = side;
    }

    public Square(Square other) {
        super(other);
        this.side = other.side;
    }

    public double getSide() {
        return side;
    }

    public void setSide(double side) {
        this.side = side;
    }


    public double area() {
        return Math.pow(side, 2);
    }


    public double perimetro() {
        return 4 * side;
    }


    public int compareTo(Figura arg0) {
        try {
            Square other = this.getClass().cast(arg0);
            return (int)(this.area() - other.area());
        } catch (ClassCastException ex) {
            return super.compareTo(arg0);
        }
    }


    public boolean equals(Object obj) {
        try {
            Square other = this.getClass().cast(obj);
            return super.equals(obj)
                    && this.side == other.getSide()
                    && this.area() == other.area()
                    && this.perimetro() == other.perimetro();
        } catch (ClassCastException ex) {
            return super.equals(obj);
        }
    }


    public String toString() {
        return String.format("\"Square\": {%s, \"side\": %.2f}",
                super.toString(), side
        );
    }
}
