package com.company;

public class Retangulo extends Figura {
    private double lado1;
    private double lado2;

    public Retangulo() {
        super();
        this.lado1 = 0;
        this.lado2 = 0;
    }

    public Retangulo(Ponto center) {
        super(center);
        this.lado1 = 0;
        this.lado2 = 0;
    }

    public Retangulo(double x, double y) {
        super(x, y);
        this.lado1 = 0;
        this.lado2 = 0;
    }

    public Retangulo(Ponto center, double sideA, double sideB) {
        super(center);
        this.lado1 = sideA;
        this.lado2 = sideB;
    }

    public Retangulo(double x, double y, double sideA, double sideB) {
        super(x, y);
        this.lado1 = sideA;
        this.lado2 = sideB;
    }

    public Retangulo(Figura other) {
        super(other);
        this.lado1 = 0;
        this.lado2 = 0;
    }

    public Retangulo(Figura other, double sideA, double sideB) {
        super(other);
        this.lado1 = sideA;
        this.lado2 = sideB;
    }

    public Retangulo(Retangulo other) {
        super(other);
        this.lado1 = other.lado1;
        this.lado2 = other.lado2;
    }

    public double getLado1() {
        return lado1;
    }

    public void setLado1(double A) {
        this.lado1 = A;
    }

    public double getLado2() {
        return lado2;
    }

    public void setLado2(double B) {
        this.lado2 = B;
    }


    public double area() {
        return lado1 * lado2;
    }


    public double perimetro() {
        return (2 * lado1) + (2 * lado2);
    }


    public int compareTo(Figura arg0) {
        try {
            Retangulo other = this.getClass().cast(arg0);
            return  (int)(this.area() - other.area());
        } catch (ClassCastException ex) {
            return super.compareTo(arg0);
        }
    }


    public boolean equals(Object obj) {
        try {
            Retangulo a = this.getClass().cast(obj);
            return super.equals(obj)
                    && this.area() == a.area()
                    && this.perimetro() == a.perimetro()
                    && this.lado1 == a.lado1
                    && this.lado2 == a.lado2;
        } catch (ClassCastException ex) {
            return super.equals(obj);
        }
    }


    public String toString() {
        return String.format("\"Rectangle\": {%s, \"sideA\": %.2f, \"sideB\": %.2f}",
                super.toString(), lado1, lado2
        );
    }
}

