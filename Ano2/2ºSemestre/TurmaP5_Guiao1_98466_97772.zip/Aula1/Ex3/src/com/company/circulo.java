package com.company;

public class circulo {
    private double raio;
    private Ponto centro;

    public circulo(double x, double y,double raio){
        Ponto centro =new Ponto(x,y);
        this.raio = raio;
        this.centro = centro;
    }
    public circulo (double raio, Ponto centro){
        this.raio = raio;
        this.centro = centro;
    }
    public double raio(){
        return raio;
    }
    public Ponto centro(){
        return centro;
    }
    public double area(){
        return Math.PI*raio*raio;
    }
    public double perimetro(){
        return Math.PI*2*raio;
    }
    public String toString()
    {
        return "Centro: " + centro().toString() + " | Raio: " + raio() + " | Área: " + area() + " | Perímetro: " + perimetro();
    }
}
