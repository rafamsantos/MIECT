package com.company;
import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int op ;
        System.out.println("-----Opções-----");
        System.out.println("1-Criar um Circulo");
        System.out.println("2-Criar um quadrado");
        System.out.println("3-Criar um retangulo");
        System.out.println("4-Comparar os circulos");
        System.out.println("5-Verificar se os circulos se intercetam");
        System.out.println("6-Terminar o programa");

        do{
            System.out.print(" Opção --> ");
            op = sc.nextInt();
            switch (op){
                case 1 : circle();
                    break;
                case 2 : square();
                    break;
                case 3 : rectangle();
                    break;
                case 4 : compCircles();
                    break;
                case 5 : interceptionCircles();
                case 6: System.out.println(" O programa vai terminar..........Terminou ! :) ");
                    break;
                default : System.out.println(" Opção inválida ");
            }
        }while(op != 4 );

    }
    public static void compCircles(){
        double x1,x2,y1,y2,raio1,raio2;
        System.out.println("Circulo 1");
        System.out.print(" Insira a abcissa do centro (x): ");
        x1 = sc.nextDouble();
        System.out.print(" Insira a ordenada do centro(y): ");
        y1 = sc.nextDouble();
        System.out.print(" Insira o raio do circulo: ");
        raio1 = sc.nextDouble();
        circulo c1 = new circulo(x1,y1,raio1);

        System.out.println("Circulo2");
        System.out.print(" Insira a abcissa do centro (x): ");
        x2 = sc.nextDouble();
        System.out.print(" Insira a ordenada do centro(y): ");
        y2 = sc.nextDouble();
        System.out.print(" Insira o raio do circulo: ");
        raio2 = sc.nextDouble();
        circulo c2 = new circulo(x2,y2,raio2);

        if(c1.raio() == c2.raio() && c1.area()==c2.area() && c1.perimetro() == c2.perimetro()){
            System.out.println(" Os circulos são iguais !! ");
        }
        else{
            System.out.println(" Os circulos não são iguais !!");
        }
    }
    public static void interceptionCircles(){
        double x1,x2,y1,y2,raio1,raio2;
        System.out.println("Circulo 1");
        System.out.print(" Insira a abcissa do centro (x): ");
        x1 = sc.nextDouble();
        System.out.print(" Insira a ordenada do centro(y): ");
        y1 = sc.nextDouble();
        System.out.print(" Insira o raio do circulo: ");
        raio1 = sc.nextDouble();
        circulo c1 = new circulo(x1,y1,raio1);

        System.out.println("Circulo2");
        System.out.print(" Insira a abcissa do centro (x): ");
        x2 = sc.nextDouble();
        System.out.print(" Insira a ordenada do centro(y): ");
        y2 = sc.nextDouble();
        System.out.print(" Insira o raio do circulo: ");
        raio2 = sc.nextDouble();
        circulo c2 = new circulo(x2,y2,raio2);
    }
    public static void  circle(){
        double raio, x, y;

        System.out.print(" Insira a abcissa do centro (x): ");
        x = sc.nextDouble();
        System.out.print(" Insira a ordenada do centro(y): ");
        y = sc.nextDouble();
        System.out.print(" Insira o raio do circulo: ");
        raio = sc.nextDouble();

        Ponto p = new Ponto(x, y);
        circulo circle = new circulo(raio,p);
        System.out.println(circle.toString());

    }
    public static Ponto square(){
        double lado, x, y;

        System.out.print(" Insira a abcissa do centro (x): ");
        x = sc.nextDouble();
        System.out.print(" Insira a ordenada do centro(y): ");
        y = sc.nextDouble();
        System.out.print(" Insira o lado do quadrado: ");
        lado = sc.nextDouble();

        Ponto p = new Ponto(x, y);
        quadrado square = new quadrado(lado,p);

        System.out.println(square.toString());

        return p;

    }
    public static void rectangle(){
        double altura, x, y, comprimento;

        System.out.print(" Insira a abcissa do centro (x): ");
        x = sc.nextDouble();
        System.out.print(" Insira a ordenada do centro(y): ");
        y = sc.nextDouble();
        System.out.print(" Insira a altura do retangulo: ");
        altura = sc.nextDouble();
        System.out.print(" Insira o comprimento do retangulo: ");
        comprimento = sc.nextDouble();

        Ponto p = new Ponto(x, y);
        retangulo rect = new retangulo(altura,comprimento,p);

        System.out.println(rect.toString());

    }
}
