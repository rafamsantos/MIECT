package com.company;

public class quadrado {
    private double lado;
    private Ponto centro;

    public quadrado(double lado , Ponto centro){
        this.centro = centro;
        this.lado = lado;
    }
    public Ponto centro(){
        return centro;
    }
    public double lado(){
        return lado;
    }
    public double area(){
        return lado*lado;
    }
    public double perimetro(){
        return lado*4;
    }
    public String toString()
    {
        return "Centro: " + centro().toString() + " | Comprimento/Altura: " + lado() + " | Área: " + area() + " | Perímetro: " + perimetro();
    }

}
