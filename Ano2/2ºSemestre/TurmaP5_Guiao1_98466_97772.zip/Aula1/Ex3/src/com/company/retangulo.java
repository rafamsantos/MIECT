package com.company;

public class retangulo {
    private double altura;
    private double comprimento;
    private Ponto centro;

    public retangulo (){
        this.altura=altura;
        this.comprimento =comprimento;
        this.centro =centro;

    }
    public double altura(){
        return altura;
    }
    public double comprimento(){
        return comprimento;
    }
    public Ponto centro(){
        return centro;
    }

    public retangulo(double altura , double comprimento,Ponto centro){
        this.altura = altura ;
        this.comprimento = comprimento;
        this.centro = centro;
    }
    public double area(){
        return altura*comprimento;
    }
    public double perimetro(){
        return altura+altura+comprimento+comprimento;
    }
    public String toString()
    {
        return "Centro: " + centro().toString() + " | Comprimento: " + comprimento() +" | Altura: " + altura() + " | Área: " + area() + " | Perímetro: " + perimetro();
    }

}
