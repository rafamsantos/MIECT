package com.company;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;
public class Main {
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        LinkedList<Pessoa> Person = new LinkedList<Pessoa>();
        int op;
        System.out.println("        Menu");
        System.out.println(" 1 - Introduzir novas pessoas na lista");
        System.out.println(" 2 - Apagar pessoas existentes na lista");
        System.out.println(" 3 - Mostrar a lista completa ");
        System.out.println(" 4 - Ordenar com base no CC");
        System.out.println(" 5 - Terminar o programa");

        do {
            System.out.print("Escolha uma Opção : ");
            op = sc.nextInt();
            switch (op) {
                case 1:
                    Person.add(adiPessoa(Person));
                    break;
                case 2:
                    removPessoa(Person);
                    break;
                case 3:
                    listaComp(Person);
                    break;
                case 4:
                    ordenacaoCC(Person);
                    break;
                case 5:
                    System.out.println("O programa encerrou ");
                    System.exit(0);
                    break;
                default : System.out.println("Opção inválida");
            }
        } while (op != 5 || op < 5);


    }

    public static Pessoa adiPessoa(LinkedList<Pessoa>Person) {
        System.out.println("Nome : ");
        Scanner ler = new Scanner(System.in);
        String nome = ler.nextLine();

        System.out.println("Nº cartão de cidadão : ");
        int cc = ler.nextInt();

        System.out.println("Data de Nascimento : ");
        System.out.println("Dia : ");
        int dia = ler.nextInt();

        System.out.println("mes : ");
        int mes = ler.nextInt();

        System.out.println("ano : ");
        int ano = ler.nextInt();

        Data date = new Data(dia, mes, ano);
        Pessoa pess = new Pessoa(nome,cc ,date);
        System.out.println("Pessoa adicionada com sucesso");
        System.out.println();

        return pess;

    }

    public static void removPessoa(LinkedList<Pessoa> Person) {
        int j=-1;
        String name;

        System.out.print("Insira o nome da pessoa que pretende remover: ");
        name = sc.nextLine();

        for(int i=0;i<Person.size();i++)
        {
            if(Person.get(i).nome().contentEquals(name))
            {
                j=i;
            }
        }

        if(j!=-1)
        {
            Person.remove(j);
            System.out.println("Pessoa removida com sucesso");
            System.out.println();
        }
        else {
            System.out.println("ERRO: Pessoa Inválida ou lista vazia");
            System.out.println();
        }
    }


    public static void listaComp(LinkedList<Pessoa> Person) {

        if(Person.size()!=0)
        {
            for(int i=0;i<Person.size();i++)
            {
                String ordem = Person.get(i).toString();
                System.out.println(ordem);
            }
        }
        else
            System.out.println("Lista Vazia");
            System.out.println();
    }
    public static void ordenacaoCC(LinkedList<Pessoa>Person){
        int size = Person.size(), i=0, n=0;
        if(!Person.isEmpty()) {
            for (i = 0; i < size; i++) {
                for (n = i + 1; n < size; n++) {
                    Pessoa pes1 = Person.get(i);
                    Pessoa pes2 = Person.get(n);
                    if (pes2.cc() < pes1.cc()) {
                        Person.set(n, pes1);
                        Person.set(i, pes2);
                    }
                }
            }
            System.out.println("Lista Ordenada por Cartão Cidadão com sucesso!");
        }
        else{
            System.out.println("Impossível fazer a ordenção , a lista está vazia");
        }
        System.out.println();

    }
}

