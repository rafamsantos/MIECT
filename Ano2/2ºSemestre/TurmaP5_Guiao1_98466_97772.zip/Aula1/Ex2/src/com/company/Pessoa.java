package com.company;

public class Pessoa {
     private String nome;
     private int cc;
     private Data dataNascimento;
    public Pessoa(String nome, int cc, Data dataNascimento){
        this.nome = nome;
        this.cc = cc;
        this.dataNascimento = dataNascimento;
    }
    public String nome(){
        return nome;
    }
    public int cc(){
        return cc;
    }
    public Data DataNascimento(){
        return dataNascimento;
    }
    public String toString()
    {
        String result = "Nome: " + nome + " | Cartão de Cidadão: " + cc + " | Data de Nascimento: " + dataNascimento.toString();
        return result;
    }

}
