package com.company;
import java.util.*;
public class Main {
    static Scanner kb = new Scanner(System.in);



    public static void main(String[] args) {
        String b, a, f;
        int i, cont, num, min, mai, space;
        char c;
        space = 0;
        mai = 0;
        min = 0;
        num = 0;
        f = "";
        System.out.println("Introduza uma frase : ");
        a = kb.nextLine();
        b = a;
        cont = a.length();
        System.out.println(cont+" caracteres");
        for(i = 0 ; i < cont ; i++ )	{
            c = a.charAt(i);
            if( Character.isUpperCase(a.charAt(i))) {
                mai++;
            }
            else if(Character.isDigit(c)) {
                num++;
            }
            else {
                min++;
            }
        }
        if(min==0 && num==0) {
            System.out.println("todos os caracteres são maiusculas");
        }
        else if(mai==0 && num==0) {
            System.out.println("todos os caracteres são minusculas");
        }
        a.trim();
        String[] p = a.split(" ");
        System.out.println(p.length + " palavras");
        for (int j = 0; j < b.length()-1; j++) {
            System.out.print(b.charAt(j+1)+b.charAt(j));
        }




    }
}

