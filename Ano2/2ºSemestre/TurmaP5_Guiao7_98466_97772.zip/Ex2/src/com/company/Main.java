package com.company;
import java.io.*;
import java.util.Scanner;


public class Main {

    public static void main(String[] args) {
        try {
            Bitmap bitmap = new Bitmap(getFicheiro()).reverseBytes();
            bitmap.exportRaw();
            Bitmap shrunk = bitmap.reducaoImagem();
            shrunk.reverseBytes().exportBMP("FiguraPequena");
            Bitmap horFlip = bitmap.flipHorizontal();
            Bitmap verFlip = bitmap.flipVertical();
            horFlip.reverseBytes().exportBMP("FiguraHorizontalFlip");
            verFlip.reverseBytes().exportBMP("FiguraVerticalFlip");
        } catch (Exception e){
            System.out.println("****** Erro! " + e.getMessage() + " ******");
            System.exit(1);
        }

    }
    public static File getFicheiro()throws IOException{
        Scanner sc = new Scanner(System.in);
        String fich ="";
        do {
            System.out.println("Qual é o nome do ficheiro ? -> ");
            fich = sc.nextLine();
        }while(fich.length()==0);
        File f = new File(fich);
        if(!f.exists() || !f.canRead() || !f.isFile()){
            throw new IOException("O ficheiro não existe");
        }
        return f;
    }
}


