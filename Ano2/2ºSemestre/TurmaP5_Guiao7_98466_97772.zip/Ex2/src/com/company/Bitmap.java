package com.company;
import java.io.*;

public class Bitmap {
    BitmapFileHeader bitmapFileHeader;
    BitmapInfoHeader bitmapInfoHeader;
    byte[] rgbQuad; // color pallete – opcional (ver abaixo)
    byte[] data; // pixel data

    public Bitmap(File f) throws IOException {
        FileInputStream fis = new FileInputStream(f);
        DataInputStream dis = new DataInputStream(fis);

        bitmapFileHeader = new BitmapFileHeader(dis.readShort(), dis.readInt(), dis.readShort(), dis.readShort(), dis.readInt());
        bitmapInfoHeader = new BitmapInfoHeader(
                dis.readInt(),dis.readInt(),dis.readInt(), dis.readShort(), dis.readShort(), dis.readInt(),dis.readInt(),dis.readInt(), dis.readInt(),dis.readInt(),dis.readInt());

        System.out.println(bitmapFileHeader + "\n" + bitmapInfoHeader);

        data = new byte[dis.available()];
        dis.read(data);

        dis.close();
        fis.close();
    }
    public Bitmap(BitmapFileHeader fileHeader, BitmapInfoHeader infoHeader, byte[] data){
        this.bitmapFileHeader = fileHeader;
        this.bitmapInfoHeader = infoHeader;
        this.data = data;
    }
    public Bitmap reverseBytes() {
        BitmapFileHeader bfh = new BitmapFileHeader(Short.reverseBytes(bitmapFileHeader.type),Integer.reverseBytes(bitmapFileHeader.size),Short.reverseBytes(bitmapFileHeader.reserved1),Short.reverseBytes(bitmapFileHeader.reserved2),Integer.reverseBytes(bitmapFileHeader.offBits));
        BitmapInfoHeader bih = new BitmapInfoHeader(Integer.reverseBytes(bitmapInfoHeader.size), Integer.reverseBytes(bitmapInfoHeader.width), Integer.reverseBytes(bitmapInfoHeader.height), Short.reverseBytes(bitmapInfoHeader.planes), Short.reverseBytes(bitmapInfoHeader.bitCount), Integer.reverseBytes(bitmapInfoHeader.compression),Integer.reverseBytes(bitmapInfoHeader.sizeImage), Integer.reverseBytes(bitmapInfoHeader.xPelsPerMeter), Integer.reverseBytes(bitmapInfoHeader.yPelsPerMeter), Integer.reverseBytes(bitmapInfoHeader.clrUsed), Integer.reverseBytes(bitmapInfoHeader.clrImportant));
        return new Bitmap(bfh, bih, data);
    }
    public void exportRaw() throws IOException{
        FileOutputStream fos = new FileOutputStream("C:\\Users\\rafa_\\Desktop\\IdeaProjects\\Programação3\\Aula7\\Ex2\\Figura.raw");
        DataOutputStream dos = new DataOutputStream(fos);
        dos.write(data);

        dos.close();
        fos.close();
    }
    public void exportBMP(String name)throws IOException{
        FileOutputStream fos = new FileOutputStream("C:/Users/rafa_/Desktop/IdeaProjects/Programação3/Aula7/Ex2/src"+ name + ".bmp");
        DataOutputStream dos = new DataOutputStream(fos);
        dos.writeShort(bitmapFileHeader.type);
        dos.writeInt(bitmapFileHeader.size);
        dos.writeShort(bitmapFileHeader.reserved1);
        dos.writeShort(bitmapFileHeader.reserved2);
        dos.writeInt(bitmapFileHeader.offBits);

        dos.writeInt(bitmapInfoHeader.size);
        dos.writeInt(bitmapInfoHeader.height);
        dos.writeInt(bitmapInfoHeader.width);
        dos.writeShort(bitmapInfoHeader.planes);
        dos.writeShort(bitmapInfoHeader.bitCount);
        dos.writeInt(bitmapInfoHeader.compression);
        dos.writeInt(bitmapInfoHeader.sizeImage);
        dos.writeInt(bitmapInfoHeader.xPelsPerMeter);
        dos.writeInt(bitmapInfoHeader.yPelsPerMeter);
        dos.writeInt(bitmapInfoHeader.clrUsed);
        dos.writeInt(bitmapInfoHeader.clrImportant);

        dos.close();
        fos.close();

    }
    public Bitmap reducaoImagem(){
        int height = Math.abs(bitmapInfoHeader.height);
        int width = Math.abs(bitmapInfoHeader.width);
        byte new_data[] = new byte[data.length/4];


        return new Bitmap(bitmapFileHeader, bitmapInfoHeader , new_data);
    }
   public Bitmap flipHorizontal(){
        int height = Math.abs(bitmapInfoHeader.height);
        int width = Math.abs(bitmapInfoHeader.width)*3;
        byte[] new_data = new byte[data.length];

        for(int i = 0 ; i < height ; i++ ){
            for(int j = 0; j < width ; j+=3){
                new_data[(((i+1)*width) - j) - 1]     = data[j + (width * i) + 2];
                new_data[(((i+1)*width) - (j+1)) - 1] = data[j + (width * i) + 1];
                new_data[(((i+1)*width) - (j+2)) - 1] = data[j + (width * i)];
            }
        }
       return new Bitmap(bitmapFileHeader, bitmapInfoHeader, new_data);
   }

    public Bitmap flipVertical() {
        int height = Math.abs(bitmapInfoHeader.height);
        int width = Math.abs(bitmapInfoHeader.width) * 3;
        byte[] new_data = new byte[data.length];

        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j+=3) {
                new_data[(((height-i-1)*width) + j)]     = data[j + (width * i)];
                new_data[(((height-i-1)*width) + (j+1))] = data[j + (width * i) + 1];
                new_data[(((height-i-1)*width) + (j+2))] = data[j + (width * i) + 2];
            }
        }
        return new Bitmap(bitmapFileHeader, bitmapInfoHeader, new_data);
    }
}


