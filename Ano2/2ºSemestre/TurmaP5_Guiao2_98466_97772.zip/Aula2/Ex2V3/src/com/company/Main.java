package com.company;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args)throws IOException {
        Scanner kb = new Scanner(System.in);
        System.out.println("qual o fixeiro de pretende ler ler");
        int cont, cont2;
        cont = 0;
        String a, l, palavras, pal;
        palavras = "";
        a = kb.nextLine();
        File fin = new File(a);
        Scanner f = new Scanner(fin);
        int i;
        i= 0;
        l = f.nextLine();
        cont = l.length();
        char[][] sop = new char[cont][cont];

        for (int j = 0; j < sop.length; j++) {
            sop[0][j] = l.charAt(j);
        }



        for (int j = 1; j < cont; j++) {
            l=f.nextLine();
            for (int j2 = 0; j2 < cont; j2++) {
                sop[j][j2] = l.charAt(j2);
            }
        }

        cont2 = i-cont;
        while (f.hasNextLine()) {
            l=f.nextLine();
            palavras += l + ",";
        }
        String[] pal2 = palavras.split(",");
        String[][] result = new String[pal2.length][2];

        for (int j = 0; j < pal2.length; j++) {
            pal = pal2[j];
            pal = pal.toUpperCase();
            pal = pal.trim();
            for (int j2 = 0; j2 < cont; j2++) {
                try {
                    for (int k = 0; k < cont; k++) {
                        if(sop[j2][k] == pal.charAt(0)) {
                            if (sop[j2+1][k] == pal.charAt(1)) {

                                boolean equals = false;

                                for (int k2 = 0; k2 < pal2.length && equals; k2++) {
                                    try {
                                        if(sop[j2+k2][k] == pal.charAt(k2)) {
                                            equals = true;
                                        }
                                    }
                                    catch(Exception e) {
                                        equals = false;
                                    }

                                }
                                if(equals != true) {
                                    result[j][0] = j2+1+","+(k+1);
                                    result[j][1] = "up";
                                }
                            }

                            else if (sop[j2+1][k+1] == pal.charAt(1)) {
                                boolean equals = false;

                                for (int k2 = 0; k2 < pal2.length && equals; k2++) {
                                    try {
                                        if(sop[j2+k2][k+k2] != pal.charAt(k2)) {
                                            equals = true;
                                        }

                                    }
                                    catch(Exception e) {
                                        equals = false;
                                    }
                                }
                                if(equals != true) {
                                    result[j][0] = j2+1+","+(k+1);
                                    result[j][1] = "upright";
                                }
                            }
                            else if (sop[j2+1][k-1] == pal.charAt(1)) {
                                boolean equals = false;

                                for (int k2 = 0; k2 < pal2.length && equals; k2++) {
                                    try {
                                        if(sop[j2+k2][k-k2] != pal.charAt(k2)) {
                                            equals = true;
                                        }

                                    }
                                    catch(Exception e) {
                                        equals = false;
                                    }
                                }
                                if(equals!=true) {
                                    result[j][0] = j2+1+","+(k+1);
                                    result[j][1] = "upleft";
                                }
                            }
                            else if (sop[j2][k+1] == pal.charAt(0)) {
                                boolean equals = false;

                                for (int k2 = 0; k2 < pal2.length && equals; k2++) {
                                    try{
                                        if(sop[j2][k+k2] != pal.charAt(k2)) {
                                            equals = true;
                                        }

                                    }
                                    catch(Exception e) {
                                        equals = false;
                                    }
                                }
                                if(equals!=true) {
                                    result[j][0] = j2+1+","+(k+1);
                                    result[j][1] = "right";
                                }
                            }
                            else if (sop[j2-1][k+1] == pal.charAt(0)) {
                                boolean equals = false;

                                for (int k2 = 0; k2 < pal2.length && equals; k2++) {
                                    try {
                                        if(sop[j2-k2][k+k2] != pal.charAt(k2)) {
                                            equals = true;
                                        }

                                    }
                                    catch(Exception e) {
                                        equals = false;
                                    }
                                }
                                if(equals!=true) {
                                    result[j][0] = j2+1+","+(k+1);
                                    result[j][1] = "downright";
                                }
                            }
                            else if (sop[j2-1][k-1] == pal.charAt(0)) {
                                boolean equals = false;

                                for (int k2 = 0; k2 < pal2.length && equals; k2++) {
                                    try{
                                        if(sop[j2-k2][k-k2] != pal.charAt(k2)) {
                                            equals = true;
                                        }

                                    }
                                    catch(Exception e) {
                                        equals = false;
                                    }
                                }
                                if(equals!=true) {
                                    result[j][0] = j2+1+","+(k+1);
                                    result[j][1] = "downleft";
                                }
                            }
                            else if (sop[j2-1][k] == pal.charAt(0)) {
                                boolean equals = false;

                                for (int k2 = 0; k2 < pal2.length && equals; k2++) {
                                    try {
                                        if(sop[j2-k2][k] != pal.charAt(k2)) {
                                            equals = true;
                                        }

                                    }
                                    catch(Exception e) {
                                        equals = false;
                                    }
                                }
                                if(equals!=true) {
                                    result[j][0] = j2+1+","+(k+1);
                                    result[j][1] = "down";
                                }
                            }
                            else if (sop[j2-1][k] == pal.charAt(0)) {
                                boolean equals = false;

                                for (int k2 = 0; k2 < pal2.length && equals; k2++) {
                                    try {
                                        if(sop[j2][k-k2] != pal.charAt(k2)) {
                                            equals = true;
                                        }

                                    }
                                    catch(Exception e) {
                                        equals = false;
                                    }
                                }
                                if(equals!=true) {
                                    result[j][0] = j2+1+","+(k+1);
                                    result[j][1] = "left";
                                }
                            }
                        }

                    }
                }
                catch(Exception e) {
                    continue;
                }
            }
        }

        for (int m = 0; m < result.length; m++) {
            System.out.println(pal2[m]+"         "+result[m][0]+"       "+result[m][1]);
        }

    }
}
