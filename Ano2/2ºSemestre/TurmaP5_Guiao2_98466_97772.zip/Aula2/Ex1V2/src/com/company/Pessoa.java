package com.company;

public class Pessoa {
}
