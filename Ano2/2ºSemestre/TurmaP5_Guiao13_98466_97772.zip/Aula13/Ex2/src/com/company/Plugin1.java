package com.company;

public class Plugin1 implements IPlugin{
    @Override
    public void fazQualQuerCoisa() {
        System.out.println("Plugin1: método invocado.");
    }
}
