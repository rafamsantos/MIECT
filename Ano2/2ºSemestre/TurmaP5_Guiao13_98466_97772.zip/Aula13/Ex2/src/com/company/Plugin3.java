package com.company;

public class Plugin3 implements IPlugin{
    @Override
    public void fazQualQuerCoisa() {
        System.out.println("Plugin3: método invocado.");
    }
}
