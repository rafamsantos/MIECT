package com.company;

public class Plugin2 implements IPlugin{
    @Override
    public void fazQualQuerCoisa() {
        System.out.println("Plugin2: método invocado.");

    }
}