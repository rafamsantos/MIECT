package com.company;

public interface IPlugin {
     void fazQualQuerCoisa();
}
