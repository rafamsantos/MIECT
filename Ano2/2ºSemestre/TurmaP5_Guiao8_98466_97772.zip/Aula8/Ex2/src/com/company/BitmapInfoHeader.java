package com.company;

public class BitmapInfoHeader {
    public int size; // the size of this header (40 bytes)
    public int width; // the bitmap width in pixels
    public int height; // the bitmap height in pixels
    public short planes; // the number of color planes being used. Must be set to 1
    public short bitCount; // the number of bits per pixel (color depth) - 1, 4, 8, 16, 24, 32
    public int compression; // the compression method being used
    public int sizeImage; // the image size. This is the size of the raw bitmap data
    public int xPelsPerMeter; // the horizontal resolution of the image (pixel per meter)
    public int yPelsPerMeter; // the vertical resolution of the image (pixel per meter)
    public int clrUsed; // the number of colors in the color palette,
    // or 0 to default to 2n
    public int clrImportant; // the number of important colors used,
    // or 0 when every color is important
    public BitmapInfoHeader(int size, int width ,int height , short planes, short bitCount , int compression, int sizeImage , int xpelsPerMeter , int yPelsPerMeter , int clrUsed , int clrImportant){
        this.size = size;
        this.height = height;
        this.width = width;
        this.planes = planes;
        this.bitCount = bitCount;
        this.compression = compression;
        this.sizeImage = sizeImage;
        this.xPelsPerMeter = xpelsPerMeter;
        this.yPelsPerMeter = yPelsPerMeter;
        this.clrUsed = clrUsed;
        this.clrImportant = clrImportant;
    }
}
