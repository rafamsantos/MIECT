package com.company;

public class BitmapFileHeader {
    public short type; // must be 'BM' to declare a bmp-file
    public int size; // specifies the size of the file in bytes
    public short reserved1; // must always be set to zero
    public short reserved2; // must always be set to zero
    public int offBits; // specifies the offset

    public BitmapFileHeader(short type, int size, short reserved1, short reserved2, int offBits) {
        this.type = type;
        this.size = size;
        this.reserved1 = reserved1;
        this.reserved2 = reserved2;
        this.offBits = offBits;
    }
    @Override
    public String toString() {
        return "BitmapFileHeader{" +
                "type=" + type +
                ", size=" + size +
                ", reserved1=" + reserved1 +
                ", reserved2=" + reserved2 +
                ", offBits=" + offBits +
                '}';
    }
}
