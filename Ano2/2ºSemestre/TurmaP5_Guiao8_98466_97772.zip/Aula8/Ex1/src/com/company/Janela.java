package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Janela implements ActionListener {
    protected Jogo game;
    protected JPanel panel = new JPanel();
    protected JToggleButton[] jtb = new JToggleButton[9];

    public Janela(Jogo game) {
        this.game = game;
    }
    public void criarJanela(){
        int i;
        JFrame frame = new JFrame("Jogo do Galo");           // Atribui titulo ao painel
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   // programa termina quando fechamos o painel
        frame.setVisible(true);                                    // coloca o painel visivel
        frame.setSize(500, 500);
        Font myFont = new Font("Serif", Font.LAYOUT_LEFT_TO_RIGHT | Font.BOLD , 50);
        panel.setLayout(new  GridLayout(3,3));       // Define um GridLayout de 3 colunas e 3 linhas
        for(i=0;i<jtb.length;i++) {
            jtb[i] = new JToggleButton();
            jtb[i].addActionListener(this);
            jtb[i].setFont(myFont);
            panel.add(jtb[i]);                          //coloca os "mosaicos"
        }
        frame.setContentPane(panel);

    }


    @Override
    public void actionPerformed(ActionEvent e) {
        JToggleButton but = (JToggleButton)e.getSource();        //retorna o objeto sobre o qual o objeto atua
        if(e.getSource() ==jtb[0]){
                game.jogada(0,0);
        }else if(e.getSource() == jtb[1]){
            game.jogada(0,1);
        }else if(e.getSource() == jtb[2]){
            game.jogada(0,2);
        }else if(e.getSource() == jtb[3]){
            game.jogada(1,0);
        }else if(e.getSource() == jtb[4]){
            game.jogada(1,1);
        }else if(e.getSource() == jtb[5]){
            game.jogada(1,2);
        }else if(e.getSource() == jtb[6]){
            game.jogada(2,0);
        }else if(e.getSource() == jtb[7]){
            game.jogada(2,1);
        }else if(e.getSource() == jtb[8]){
            game.jogada(2,2);
        }
        but.setText(game.ultimoJogador());          //escreve no painel selecionado o ultimo jogador a jogar
        if(game.jogoTerminou().equals(game.JogadorX())) {
            JOptionPane.showMessageDialog(panel, "JogadorX Venceu");
            System.exit(0);
        } else if(game.jogoTerminou().equals(game.JogadorO())) {
            JOptionPane.showMessageDialog(panel, "JogadorO Venceu");
            System.exit(0);
         }
        else if(game.jogoTerminou().equals("Empate")) {
            JOptionPane.showMessageDialog(panel, "Empate");
            System.exit(0);
        }
    }
}
