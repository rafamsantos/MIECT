package com.company;

public class Jogo {
    private String JogadorX;
    private String JogadorO;
    private String[][] jogatana;
    private String first;
    private int nJogadas;

    public Jogo(String first ){
        this.JogadorX = "X";
        this.JogadorO = "O";
        this.jogatana = new String[3][3];
        for(int i=0;i<3;i++) {
            for(int z=0;z<3;z++) {
                jogatana[i][z]=" ";
            }
        }
        this.first = first;
        this.nJogadas = 0;
    }
    public String JogadorX(){ return JogadorX; }
    public String JogadorO(){ return JogadorO; }
    public String[][] jogatana(){ return jogatana; }
    public String first() { return first; }
    public int nJogadas(){ return nJogadas; }

    public boolean Vencedor(String jogador){
        if(jogatana[0][0].equals(jogador) && jogatana[0][1].equals(jogador) && jogatana[0][2].equals(jogador))
            return true;
        else if(jogatana[1][0].equals(jogador) && jogatana[1][1].equals(jogador) && jogatana[1][2].equals(jogador))
            return true;
        else if(jogatana[2][0].equals(jogador) && jogatana[2][1].equals(jogador) && jogatana[2][2].equals(jogador))
            return true;
        else if(jogatana[0][0].equals(jogador) && jogatana[1][0].equals(jogador) && jogatana[2][0].equals(jogador))
            return true;
        else if(jogatana[0][1].equals(jogador) && jogatana[1][1].equals(jogador) && jogatana[2][1].equals(jogador))
            return true;
        else if(jogatana[0][2].equals(jogador) && jogatana[1][2].equals(jogador) && jogatana[2][2].equals(jogador))
            return true;
        else if(jogatana[0][2].equals(jogador) && jogatana[1][1].equals(jogador) && jogatana[2][0].equals(jogador))
            return true;
        else if(jogatana[0][0].equals(jogador) && jogatana[1][1].equals(jogador) && jogatana[2][2].equals(jogador))
            return true;
        else
            return false;
    }
    public int jogada(int l , int c){
        if(first.equals(JogadorX)) {							//Se o Jogador X
            if(jogatana[l][c].equals(" ")) {					//for o primeiro
                if(nJogadas%2==0)
                    jogatana[l][c] = JogadorX();
                else
                    jogatana[l][c] = JogadorO();
                nJogadas++;
            }
            return nJogadas;
        }
        else {													//Se o  Jogador O
            if(jogatana[l][c].equals(" ")) {					//for o primeiro
                if(nJogadas%2==0)
                    jogatana[l][c] = JogadorO();
                else {
                    jogatana[l][c] = JogadorX();
                    nJogadas++;
                }
            }
            return nJogadas;
        }
    }
    public String jogoTerminou()
    {
        if(Vencedor(JogadorX))
            return JogadorX;
        else if(Vencedor(JogadorO))
            return JogadorO;
        else if(nJogadas() == 9)
            return "Empate";
        else
            return " ";
    }
    public String ultimoJogador() {
        if (first.equals(JogadorX)) {                        //Se o Jogador X
            if (nJogadas % 2 == 0)                                //for o primeiro
                return JogadorO();
            else
                return JogadorX();
        } else {                                                //Se o Jogador O
            if (nJogadas % 2 == 0)                                //for o primeiro
                return JogadorX();
            else
                return JogadorO();
        }
    }
}

