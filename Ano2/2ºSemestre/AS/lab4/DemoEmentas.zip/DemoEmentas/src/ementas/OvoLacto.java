package ementas;

public class OvoLacto extends Alimento {

	public OvoLacto(String nome, double proteinas, double calorias, double peso) {
		super(proteinas, calorias, peso);
	}

}