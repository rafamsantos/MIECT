package com.company;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class Main {
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws IOException {


        Path path = Paths.get("C:\\Users\\rafa_\\Desktop\\IdeaProjects\\Programação3\\Aula11\\b)\\policarpo.txt");
        BufferedReader reader = new BufferedReader(new FileReader(path.toFile()));

        Set<String> wordsOfArticle = new HashSet<>();
        Map<String , Integer> frequency = new HashMap<>();
        String line = reader.readLine();
        int totalWords = 0;

        while(line != null){
            //  System.out.println("Processing line : "+line);      // Imprime no ecrã cada linha uma a uma

            if(!line.trim().equals("") ){
                String[] words = line.split(" ");
                totalWords += words.length;

                for(String word : words){
                    String cleanedUpString = word.toLowerCase().replace(",", "").replace(":","").replace("\"","").replace(".","");
                    wordsOfArticle.add(cleanedUpString);
                }

                for(String word :words){
                    if(word == null || word.trim().equals("")) continue;

                    String processed = word.toLowerCase();
                    if(frequency.containsKey(processed)){
                        frequency.put(processed, frequency.get(processed+1));       // incrementa 1 cada vez que a palavra aparece
                    }else{
                        frequency.put(processed,1);
                    }
                }

            }
            line = reader.readLine();
        }
        System.out.println(wordsOfArticle);
        System.out.println();
        System.out.println("Número de palavras únicas : ");
        System.out.print(wordsOfArticle.size()+"\n");
        System.out.println("Número total de palavras : ");
        System.out.print(totalWords);
        System.out.println();
        System.out.println(frequency);

        int mostFrequentlyUsed = 0;
        String theWord = null;
        for(String word : frequency.keySet()){
            Integer val = frequency.get(word);
            if(frequency.get(word)>mostFrequentlyUsed){
                mostFrequentlyUsed = val;
                theWord = word;
            }
        }
        System.out.println("Palavra mais frequente : "+ theWord + "-> "+ mostFrequentlyUsed+" vezes ");

    }
}
