
package com.company;
import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.io.BufferedReader;
import java.util.HashSet;

public class Main {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) throws IOException {

        Path path = Paths.get("C:\\Users\\rafa_\\Desktop\\IdeaProjects\\Programação3\\Aula11\\b)\\policarpo.txt");


        Scanner scanner = new Scanner(path);
        ArrayList<String> allWords = new ArrayList();
        while (scanner.hasNextLine()) {
            String linha = scanner.nextLine();
            String[] words = linha.split(" ");
            List<String> wordList = Arrays.asList(words);
            allWords.addAll(wordList);
        }
        scanner.close();
        Collections.sort(allWords);
        System.out.println(allWords);


    }
}