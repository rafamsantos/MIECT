CREATE VIEW ViewViagens	AS
SELECT * 
FROM Projeto.Viagem 
WHERE id IN (
    SELECT Projeto.Viagem.id 
    FROM Projeto.Viagem 
    JOIN Projeto.Paragens partida ON Viagem.id_partida = partida.id 
    JOIN Projeto.Paragens chegada ON Viagem.id_chegada = chegada.id 
    
); 