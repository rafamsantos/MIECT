CREATE TRIGGER trgDescontarSaldoBilhete
ON Projeto.Passageiros
AFTER UPDATE
AS
BEGIN
    -- Vari�veis para armazenar os valores do bilhete
    DECLARE @id_bilhete INT
    DECLARE @saldo_anterior DECIMAL(10, 2)
    DECLARE @saldo_atual DECIMAL(10, 2)
	Declare @cc varChar(9)

    -- Obter os valores do passageiro atualizados
    SELECT @id_bilhete = i.id_bilhete,  @saldo_anterior = i.saldo, @saldo_atual = i.saldo,@cc = i.cc
    FROM inserted i
    INNER JOIN deleted d ON i.cc = d.cc
    INNER JOIN Bilhete b ON i.id_bilhete = b.id

    -- Calcular a diferen�a de saldo
    DECLARE @diferenca_saldo DECIMAL(10, 2)
    SET @diferenca_saldo = @saldo_atual - @saldo_anterior

    -- Atualizar o saldo do passageiro
    UPDATE Passageiros
    SET saldo = saldo - @diferenca_saldo
    WHERE cc = cc
      AND id_bilhete = @id_bilhete
END

drop trigger Projeto.trgDescontarSaldoBilhete
