
CREATE TRIGGER verificaSaldo_Trigger
ON Projeto.Passageiros
AFTER UPDATE
AS
BEGIN
    -- Verificar apenas quando a coluna id_bilhete for atualizada
    IF UPDATE(id_bilhete)
    BEGIN
        -- Verificar somente se o novo valor de id_bilhete for alterado	(indicando compra de bilhete)
        IF EXISTS (
            SELECT 1	-- verifica a exist�ncia de pelo menos uma linha
            FROM inserted i
            INNER JOIN Projeto.Passageiros p ON i.cc = p.cc
            INNER JOIN Projeto.Bilhete b ON i.id_bilhete = b.id
            WHERE p.saldo < b.pre�o
        )
        BEGIN
            -- Reverter a atualiza��o definindo o valor anterior
            RAISERROR ('Saldo insuficiente.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END
    END
END;
drop trigger verificaSaldo_Trigger
