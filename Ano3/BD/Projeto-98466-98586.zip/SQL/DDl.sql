create table Projeto.Empresa(
	nome		varChar(30) not null,
	id			int not null,
	d_criacao	date not null,
	NIF			varChar(9)  not null
	primary key(id)

);
drop table Projeto.Empresa


create table Projeto.Veiculos(
	id			int not null,
	id_empresa	int not null,
	id_viagem	int not null,
	primary key(id)
);
drop table Projeto.Veiculos

create table Projeto.Viagem(
	id			int not null, 
	pre�o		float not null,
	id_condutor int ,
	id_veiculo	int,
	primary key(id)
);
alter table Projeto.Viagem add id_partida int;
alter table Projeto.Viagem add id_chegada int;
alter table Projeto.Viagem add Hora time;
alter table Projeto.Viagem drop hora


drop table Projeto.Viagem

create table Projeto.Passageiros(
    cc		varChar(9) not null,
	idade	int not null,
	f_name	varChar(30) not null,
	l_name	varChar(30) not null,
	NIF		varChar(9) not null,
	primary key(cc)

);
alter table Projeto.Passageiros add username varChar(30)
alter table Projeto.Passageiros add user_password varChar(30)
alter table Projeto.Passageiros add id_bilhete int 
alter table Projeto.Passageiros add saldo float
update Projeto.Passageiros set saldo = 20 where username = 'rafa123'
drop table Projeto.Passageiros

create table Projeto.Bilhete(
	id				int  not null,
	pre�o			float not null,
	num_lugar		varChar not null,
	id_partida		int not null,
	id_chegada		int not null,
	id_viagem		int not null,
	valid_flag		int null, --> alter table para 0
	primary key(id)
);
alter table Projeto.Bilhete alter column num_lugar int
alter table Projeto.Bilhete add Hora time;
alter table Projeto.Bilhete add Hora_chegada time;
drop table Projeto.Bilhete
update Projeto.Bilhete	set valid_flag = 0 where num_lugar = 10

create table Projeto.Paragens(
	nome	varChar(30) not null,
	id		int not null,
	primary key(id)
);
alter table Projeto.Paragens alter column id_viagem int
alter table Projeto.Paragens drop column id_viagem
drop table Projeto.Paragens


create table Projeto.TipoVeiculo(
	designa��o varChar(30) not null,
	id_veiculo int not null,
	primary key(designa��o),
);
drop table Projeto.TipoVeiculo

create table Projeto.Condutor(
	cc varChar(9) not null,
	id_empresa int not null,
	f_name varChar(30) not null,
	l_name varChar(30) not null,
	idade	int not null,
	id int not null,
	primary key(id)
);

drop table Projeto.Condutor

alter table Projeto.Veiculos add constraint id_empresa_fk foreign key(id_empresa) references Projeto.Empresa(id)
--alter table Projeto.Veiculos drop constraint id_empresa_fk 

alter table Projeto.Veiculos add constraint id_viagem_fk foreign key(id_viagem) references Projeto.Viagem(id)
--alter table Projeto.Veiculos drop constraint id_viagem_fk

alter table Projeto.Viagem add constraint id_condutor_fk foreign key(id_condutor) references Projeto.Condutor(id)
--alter table Projeto.Viagem drop constraint id_condutor_fk 

alter table Projeto.Condutor add constraint id_empresa_condutor_fk foreign key(id_empresa) references Projeto.Empresa(id)
--alter table Projeto.Condutor drop constraint id_empresa_condutor_fk 

alter table Projeto.Bilhete add constraint id_viagem_passageiro_fk foreign key(id_viagem) references Projeto.Viagem(id)
--alter table Projeto.Bilhete drop constraint id_viagem_passageiro_fk 

alter table Projeto.Bilhete add constraint id_chegada_fk foreign key(id_chegada) references Projeto.Paragens(id)
--alter table Projeto.Bilhete drop constraint nome_chegada_fk

alter table Projeto.Bilhete add constraint id_partida_fk foreign key(id_partida) references Projeto.Paragens(id)
--alter table Projeto.Bilhete drop constraint nome_partida_fk 

alter table Projeto.TipoVeiculo add constraint id_veiculo_fk foreign key(id_veiculo) references Projeto.Veiculos(id)
--alter table Projeto.TipoVeiculo drop constraint id_veiculo_fk 

alter table Projeto.Passageiros add constraint id_bilhete_fk foreign key(id_bilhete) references Projeto.Bilhete(id)
--alter table Projeto.Passageiros drop constraint id_bilhete_fk 
-- alterar viagem , bilhete, paragens