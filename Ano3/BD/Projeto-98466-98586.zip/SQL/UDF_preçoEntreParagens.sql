-- pre�o entre paragens � o mesmo
-- se numa viagem houver 1 paragem , pre�o mantem-se
-- se houver 2, pre�o duplica
-- 3 triplica 
-- etc.
CREATE FUNCTION Projeto.PrecoPParagens(@id_viagem INT)
RETURNS DECIMAL(10, 2)
AS
BEGIN
    DECLARE @preco DECIMAL(10, 2)

    SELECT @preco = pre�o
    FROM Viagem
    WHERE id = @id_viagem

    DECLARE @num_paragens INT
    SELECT @num_paragens = COUNT(*) 
    FROM Paragens
    WHERE id_viagem = @id_viagem

    IF @num_paragens > 0
        SET @preco = @preco / @num_paragens

    RETURN @preco
END

drop function Projeto.PrecoPParagens
