-- inserir na tabela Bilhetes
-- id viagens - qualquer n�
-- id condutores - come�a com 1111
-- id empresas -- come�a com 2222
-- id _veiculo - se for comboio id[1-100], se for autocarro id=[101-200]

--empresa
insert into Projeto.Empresa values ('Transdev' ,2222,'1/1/1997', 123456789 )
--condutor
insert into Projeto.Condutor values(185028574 , 2222, 'Jo�o', 'Ricardo', 45 , 1111);
insert into Projeto.Condutor values(185028574 , 2222, 'Maria', 'Santos', 56 , 11112);
update Projeto.Condutor set cc = 876938574 where f_name = 'Maria'
insert into Projeto.Condutor values(123459876 , 2222, 'Joaquim', 'Ant�nio', 32 , 11113);
insert into Projeto.Condutor values(106382716, 2222 , 'Eduardo', 'Madeira' , 54 , 11114);
insert into Projeto.Condutor values(106382716, 2222 , 'Luis Filipe', 'Vieira' , 60 , 11115);

-- viagem
insert into Projeto.Viagem values(1,13.90,1111,102,1, 3, '14:10' , '15:10');
--alter table Projeto.Viagem add hora_chegada time;
insert into Projeto.Viagem values(2,13.90,11112,106,1, 3, '18:55', '19:20');
                               -- id pre�o id_c  id_v P  D   h_p   h_c
insert into Projeto.Viagem values(3,13.90,11113,1067,3, 4, '8:30', '9:45');
insert into Projeto.Viagem values(4,13.90,11113,156,3, 4, '10:30', '11:30');
update Projeto.Viagem set id_veiculo = 167 where hora_chegada = '9:45'
insert into Projeto.Viagem values(5,15.08,11114,4,3, 13, '08:48', '10:30');

--Paragens
insert into Projeto.Paragens values ('Tondela', 1)
update Projeto.Paragens set id_viagem = 1 where id = 1
insert into Projeto.Paragens values ('Albergaria-a-velha', 2)
update Projeto.Paragens set id_viagem = 1 where id = 3

insert into Projeto.Paragens values ('Aveiro', 3)	
insert into Projeto.Paragens values ('Viseu', 4)
update Projeto.Paragens set id_viagem = 3 where id = 4
insert into Projeto.Paragens values ('Quintans', 5)
update Projeto.Paragens set id_viagem = 5 where id = 5
insert into Projeto.Paragens values ('Oia', 6)
update Projeto.Paragens set id_viagem = 5 where id = 6
insert into Projeto.Paragens values ('Oliveira do Bairro', 7)
update Projeto.Paragens set id_viagem = 5 where id = 7
insert into Projeto.Paragens values ('Sangalhos', 8)
update Projeto.Paragens set id_viagem = 5 where id = 8
insert into Projeto.Paragens values ('Mongofores', 9)
update Projeto.Paragens set id_viagem = 5 where id = 9
insert into Projeto.Paragens values ('Pampilhosa', 10)
update Projeto.Paragens set id_viagem = 5 where id = 10
insert into Projeto.Paragens values ('Mealhada', 11)
update Projeto.Paragens set id_viagem = 5 where id = 11
insert into Projeto.Paragens values ('Coimbra B', 12)
update Projeto.Paragens set id_viagem = 5 where id = 12
insert into Projeto.Paragens values ('Sta Comba Dao', 13)
update Projeto.Paragens set id_viagem = 5 where id = 13
insert into Projeto.Paragens values ('Aveiro', 14, 3)
insert into Projeto.Paragens values ('Aveiro', 15, 5)
insert into Projeto.Paragens values ('Viseu', 16,3)



--bilhetes viagem com id 1-autocarro
            -- id pre�o n_lugar  id_p id_c id_viagem vf h_p h_c
insert into Projeto.Bilhete values(1 , 13.90, 1, 1, 3, 1,0,'14:10', '15:10')
insert into Projeto.Bilhete values(2 , 13.90, 2, 1, 3, 1,0,'14:10', '15:10')
insert into Projeto.Bilhete values(3 , 13.90, 3, 1, 3, 1,0,'14:10', '15:10')
insert into Projeto.Bilhete values(4 , 13.90, 4, 1, 3, 1,1,'14:10', '15:10')
insert into Projeto.Bilhete values(5 , 13.90, 5, 1, 3, 1,1,'14:10', '15:10')
insert into Projeto.Bilhete values(6 , 13.90, 6, 1, 3, 1,0,'14:10', '15:10')
insert into Projeto.Bilhete values(7 , 13.90, 7, 1, 3, 1,1,'14:10', '15:10')
insert into Projeto.Bilhete values(8 , 13.90, 8, 1, 3, 1,1,'14:10', '15:10')
insert into Projeto.Bilhete values(9 , 13.90, 9, 1, 3, 1,0,'14:10', '15:10')
insert into Projeto.Bilhete values(10 ,13.90, 10,1, 3, 1,0,'14:10', '15:10')

-- bilhetes viagem com id 5-comboio
-- id pre�o n_lugar  id_p id_c id_viagem vf h_p h_c
insert into Projeto.Bilhete values(11 , 15.08, 1, 3, 13, 5,0,'08:48', '10:30')
insert into Projeto.Bilhete values(12 , 15.08, 2, 3, 13, 5,1,'08:48', '10:30')
insert into Projeto.Bilhete values(13 , 15.08, 3, 3, 13, 5,1,'08:48', '10:30')
insert into Projeto.Bilhete values(14 , 15.08, 4, 3, 13, 5,1,'08:48', '10:30')
insert into Projeto.Bilhete values(15 , 15.08, 5, 3, 13, 5,0,'08:48', '10:30')
insert into Projeto.Bilhete values(16 , 15.08, 6, 3, 13, 5,0,'08:48', '10:30')
insert into Projeto.Bilhete values(17 , 15.08, 7, 3, 13, 5,0,'08:48', '10:30')
insert into Projeto.Bilhete values(18 , 15.08, 8, 3, 13, 5,0,'08:48', '10:30')
insert into Projeto.Bilhete values(19 , 15.08, 9, 3, 13, 5,1,'08:48', '10:30')
insert into Projeto.Bilhete values(20 , 15.08, 10, 3, 13, 5,0,'08:48', '10:30')



delete from Projeto.Bilhete

