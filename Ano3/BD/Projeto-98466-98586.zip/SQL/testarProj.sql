SELECT Projeto.Paragens.nome, Projeto.Viagem.id
FROM Projeto.Viagem
JOIN Projeto.Paragens ON Projeto.Viagem.id_partida = Projeto.Paragens.id
WHERE Projeto.Paragens.nome = 'Aveiro';



SELECT id_viagem FROM Projeto.Paragens
JOIN Projeto.Paragens ON Projeto.Viagem.id_partida = Projeto.Paragens.id
WHERE Projeto.Paragens.nome = 'Aveiro'

SELECT id_viagem
FROM Projeto.Paragens
join Projeto.Viagem on Projeto.Paragens.id_viagem = Projeto.Viagem.id
where Projeto.Paragens.nome = 'Aveiro';


SELECT id_viagem
FROM Projeto.Paragens
join Projeto.Viagem on Projeto.Paragens.id_viagem = Projeto.Viagem.id
where Projeto.Paragens.nome = 'Viseu';

SELECT id_viagem
FROM Projeto.Paragens
WHERE id_viagem IN (
    SELECT id_viagem
    FROM Projeto.Paragens
    JOIN Projeto.Viagem ON Projeto.Paragens.id_viagem = Projeto.Viagem.id
    WHERE Projeto.Paragens.nome = 'Aveiro'
)
AND nome = 'Viseu';


SELECT Projeto.Viagem.id
FROM Projeto.Viagem
JOIN Projeto.Paragens ON Projeto.Viagem.id = Projeto.Paragens.id_viagem
WHERE Projeto.Paragens.nome = 'Aveiro'
  AND Projeto.Paragens.id_viagem IN (
    SELECT Projeto.Paragens.id_viagem
    FROM Projeto.Paragens
    JOIN Projeto.Viagem ON Projeto.Paragens.id_viagem = Projeto.Viagem.id
    WHERE Projeto.Paragens.nome = 'Viseu'
  );

 SELECT Projeto.Viagem.id
FROM Projeto.Viagem
JOIN Projeto.Paragens partida ON Viagem.id_partida = partida.id
JOIN Projeto.Paragens chegada ON Viagem.id_chegada = chegada.id
WHERE partida.nome = 'Aveiro'
  AND chegada.nome = 'Sta Comba Dao';

 SELECT *
FROM Projeto.Viagem
WHERE id = (
    SELECT Projeto.Viagem.id
    FROM Projeto.Viagem
    JOIN Projeto.Paragens partida ON Viagem.id_partida = partida.id
    JOIN Projeto.Paragens chegada ON Viagem.id_chegada = chegada.id
    WHERE partida.nome = 'Aveiro'
      AND chegada.nome = 'Sta Comba Dao'
);
select * from Projeto.Passageiros 

insert into Projeto.Passageiros values(123456789,21,'Rafael', 'Santos', 123456789,1,'rafa123', 'Rafa123.')

SELECT Projeto.Viagem.id,Projeto.Viagem.pre�o,Projeto.Viagem.id_partida,Projeto.Viagem.id_chegada, Projeto.Viagem.Hora,Projeto.Viagem.hora_chegada FROM Projeto.Viagem 
join Projeto.Bilhete ON Projeto.Bilhete.id = Projeto.Viagem.id
join Projeto.Passageiros on Projeto.Bilhete.id = Projeto.Bilhete.id_viagem


Select Projeto.Bilhete.num_lugar from Projeto.Bilhete
join Projeto.Viagem on Projeto.Viagem.id = Projeto.Bilhete.id_viagem
where Projeto.Bilhete.valid_flag = '0' and Projeto.Bilhete.id_viagem = '1';


update Projeto.Bilhete set valid_flag= 0 where num_lugar = 3 and id_viagem=1;

update Projeto.Passageiros set id_bilhete = 3 where idade =21

Select Projeto.Viagem.id,Projeto.Viagem.pre�o,Projeto.Bilhete.num_lugar ,Projeto.Viagem.id_veiculo,Projeto.Viagem.Hora, Projeto.Viagem.hora_chegada 
from Projeto.Viagem
join Projeto.Bilhete on Projeto.Bilhete.id_viagem = Projeto.Viagem.id 
join Projeto.Passageiros on Projeto.Passageiros.id_bilhete = Projeto.Bilhete.id;


update Projeto.Passageiros set saldo = 10;

