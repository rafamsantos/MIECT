﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto
{
    public partial class FormLogin : Form
    {
        private Form frmAtivo;
        Form1 form1;
        public FormLogin(Form1 form1)
        {
            InitializeComponent();
            this.form1 = form1;
        }

        private void CriarConta_btn_Click(object sender, EventArgs e)
        {
            FormCriarConta formCriarConta = new FormCriarConta();
            formCriarConta.Show();
        }


        private void ActiveFormClose()
        {
            if (frmAtivo != null)
            {
                frmAtivo.Close();
            }
        }

        

        private void username_textBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void login_btn_Click(object sender, EventArgs e)
        {
            string username = username_textBox.Text;
            string user_password = textBox1.Text;
            GlobalVar.Username = username;

            string query = $"SELECT COUNT(*) FROM Projeto.Passageiros WHERE username = '{username}' AND user_password = '{user_password}'";


            using (SqlConnection sqlcon = new SqlConnection(GlobalVar.connection))
            {
                sqlcon.Open();
                SqlCommand sqlQuery = new SqlCommand(query, sqlcon);

                int result = (int)sqlQuery.ExecuteScalar();

                if (result > 0)
                {
                    MessageBox.Show("Login efetuado com sucesso.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                else
                {
                    // utilizador nao valido
                    MessageBox.Show("Credenciais Inválidas.Tente novamente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }

                sqlcon.Close();

                // close the current form
                form1.UserName(username);
                this.Close();
                
            }



        }
        

        private void FormLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
