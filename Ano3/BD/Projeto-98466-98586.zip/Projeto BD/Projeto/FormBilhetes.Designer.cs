﻿namespace Projeto
{
    partial class FormBilhetes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewBilhetes = new DataGridView();
            ver_bilhetes_btn = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewBilhetes).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewBilhetes
            // 
            dataGridViewBilhetes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewBilhetes.Location = new Point(47, 92);
            dataGridViewBilhetes.Name = "dataGridViewBilhetes";
            dataGridViewBilhetes.RowHeadersWidth = 62;
            dataGridViewBilhetes.RowTemplate.Height = 33;
            dataGridViewBilhetes.Size = new Size(798, 355);
            dataGridViewBilhetes.TabIndex = 0;
            dataGridViewBilhetes.CellContentClick += dataGridViewBilhetes_CellContentClick;
            // 
            // ver_bilhetes_btn
            // 
            ver_bilhetes_btn.Location = new Point(332, 17);
            ver_bilhetes_btn.Name = "ver_bilhetes_btn";
            ver_bilhetes_btn.Size = new Size(235, 69);
            ver_bilhetes_btn.TabIndex = 1;
            ver_bilhetes_btn.Text = "Ver bilhetes";
            ver_bilhetes_btn.UseVisualStyleBackColor = true;
            ver_bilhetes_btn.Click += ver_bilhetes_btn_Click;
            // 
            // FormBilhetes
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(890, 682);
            Controls.Add(ver_bilhetes_btn);
            Controls.Add(dataGridViewBilhetes);
            Name = "FormBilhetes";
            Text = "FormBilhetes";
            Load += FormBilhetes_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewBilhetes).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridViewBilhetes;
        private Button ver_bilhetes_btn;
    }
}