﻿namespace Projeto
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            painelPrincipal = new Panel();
            MinhasViagens_bt = new Button();
            procViagem = new Button();
            login_btn = new Button();
            painel_inicial = new Panel();
            labelPP = new Label();
            Perfil_bt = new Button();
            painelPrincipal.SuspendLayout();
            painel_inicial.SuspendLayout();
            SuspendLayout();
            // 
            // painelPrincipal
            // 
            painelPrincipal.BackColor = SystemColors.ControlDark;
            painelPrincipal.Controls.Add(Perfil_bt);
            painelPrincipal.Controls.Add(MinhasViagens_bt);
            painelPrincipal.Controls.Add(procViagem);
            painelPrincipal.Controls.Add(login_btn);
            painelPrincipal.Location = new Point(0, 2);
            painelPrincipal.Margin = new Padding(4, 5, 4, 5);
            painelPrincipal.Name = "painelPrincipal";
            painelPrincipal.Size = new Size(226, 747);
            painelPrincipal.TabIndex = 0;
            // 
            // MinhasViagens_bt
            // 
            MinhasViagens_bt.Location = new Point(4, 301);
            MinhasViagens_bt.Margin = new Padding(4, 5, 4, 5);
            MinhasViagens_bt.Name = "MinhasViagens_bt";
            MinhasViagens_bt.Size = new Size(217, 90);
            MinhasViagens_bt.TabIndex = 2;
            MinhasViagens_bt.Text = "As minhas viagens";
            MinhasViagens_bt.UseVisualStyleBackColor = true;
            MinhasViagens_bt.Click += MinhasViagens_bt_Click;
            // 
            // procViagem
            // 
            procViagem.Location = new Point(4, 175);
            procViagem.Margin = new Padding(4, 5, 4, 5);
            procViagem.Name = "procViagem";
            procViagem.Size = new Size(217, 97);
            procViagem.TabIndex = 1;
            procViagem.Text = "Procurar viagem";
            procViagem.UseVisualStyleBackColor = true;
            procViagem.Click += procViagem_Click;
            // 
            // login_btn
            // 
            login_btn.Location = new Point(4, 42);
            login_btn.Margin = new Padding(4, 5, 4, 5);
            login_btn.Name = "login_btn";
            login_btn.Size = new Size(217, 98);
            login_btn.TabIndex = 0;
            login_btn.Text = "Login / Registar";
            login_btn.UseVisualStyleBackColor = true;
            login_btn.Click += login_btn_Click;
            // 
            // painel_inicial
            // 
            painel_inicial.Controls.Add(labelPP);
            painel_inicial.Location = new Point(230, 2);
            painel_inicial.Margin = new Padding(4, 5, 4, 5);
            painel_inicial.Name = "painel_inicial";
            painel_inicial.Size = new Size(913, 747);
            painel_inicial.TabIndex = 1;
            // 
            // labelPP
            // 
            labelPP.AutoSize = true;
            labelPP.Font = new Font("Segoe UI", 26.25F, FontStyle.Regular, GraphicsUnit.Point);
            labelPP.Location = new Point(250, 175);
            labelPP.Margin = new Padding(4, 0, 4, 0);
            labelPP.Name = "labelPP";
            labelPP.Size = new Size(400, 71);
            labelPP.TabIndex = 0;
            labelPP.Text = "Página Principal";
            // 
            // Perfil_bt
            // 
            Perfil_bt.Location = new Point(5, 421);
            Perfil_bt.Margin = new Padding(4, 5, 4, 5);
            Perfil_bt.Name = "Perfil_bt";
            Perfil_bt.Size = new Size(217, 90);
            Perfil_bt.TabIndex = 3;
            Perfil_bt.Text = "Perfil";
            Perfil_bt.UseVisualStyleBackColor = true;
            Perfil_bt.Click += Perfil_bt_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1143, 750);
            Controls.Add(painel_inicial);
            Controls.Add(painelPrincipal);
            Margin = new Padding(4, 5, 4, 5);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            painelPrincipal.ResumeLayout(false);
            painel_inicial.ResumeLayout(false);
            painel_inicial.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel painelPrincipal;
        private Button procViagem;
        private Button login_btn;
        private Panel painel_inicial;
        private Label labelPP;
        private Button MinhasViagens_bt;
        private Button Perfil_bt;
    }
}