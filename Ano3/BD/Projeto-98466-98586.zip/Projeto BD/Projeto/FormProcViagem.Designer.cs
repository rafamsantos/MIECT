﻿namespace Projeto
{
    partial class FormProcViagem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Partida_textBox = new TextBox();
            Partida_label = new Label();
            textBox1 = new TextBox();
            Chegada_label = new Label();
            comboBox1 = new ComboBox();
            viagemDe_label = new Label();
            dateTimePicker1 = new DateTimePicker();
            Data_label = new Label();
            ProcViagem_btn = new Button();
            dataGridView1 = new DataGridView();
            dataGridViewBilhete = new DataGridView();
            viagens_label = new Label();
            BilhetesDisp_label = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewBilhete).BeginInit();
            SuspendLayout();
            // 
            // Partida_textBox
            // 
            Partida_textBox.Location = new Point(56, 82);
            Partida_textBox.Margin = new Padding(4, 5, 4, 5);
            Partida_textBox.Name = "Partida_textBox";
            Partida_textBox.Size = new Size(135, 31);
            Partida_textBox.TabIndex = 0;
            // 
            // Partida_label
            // 
            Partida_label.AutoSize = true;
            Partida_label.Location = new Point(56, 52);
            Partida_label.Margin = new Padding(4, 0, 4, 0);
            Partida_label.Name = "Partida_label";
            Partida_label.Size = new Size(66, 25);
            Partida_label.TabIndex = 1;
            Partida_label.Text = "Partida";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(234, 82);
            textBox1.Margin = new Padding(4, 5, 4, 5);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(135, 31);
            textBox1.TabIndex = 2;
            // 
            // Chegada_label
            // 
            Chegada_label.AutoSize = true;
            Chegada_label.Location = new Point(234, 52);
            Chegada_label.Margin = new Padding(4, 0, 4, 0);
            Chegada_label.Name = "Chegada_label";
            Chegada_label.Size = new Size(82, 25);
            Chegada_label.TabIndex = 3;
            Chegada_label.Text = "Chegada";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Comboio", "Autocarro" });
            comboBox1.Location = new Point(414, 82);
            comboBox1.Margin = new Padding(4, 5, 4, 5);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(135, 33);
            comboBox1.TabIndex = 4;
            // 
            // viagemDe_label
            // 
            viagemDe_label.AutoSize = true;
            viagemDe_label.Location = new Point(414, 52);
            viagemDe_label.Margin = new Padding(4, 0, 4, 0);
            viagemDe_label.Name = "viagemDe_label";
            viagemDe_label.Size = new Size(106, 25);
            viagemDe_label.TabIndex = 5;
            viagemDe_label.Text = "Viagem de :";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(587, 82);
            dateTimePicker1.Margin = new Padding(4, 5, 4, 5);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(243, 31);
            dateTimePicker1.TabIndex = 6;
            // 
            // Data_label
            // 
            Data_label.AutoSize = true;
            Data_label.Location = new Point(587, 52);
            Data_label.Margin = new Padding(4, 0, 4, 0);
            Data_label.Name = "Data_label";
            Data_label.Size = new Size(63, 25);
            Data_label.TabIndex = 7;
            Data_label.Text = "Data : ";
            Data_label.Click += Data_label_Click;
            // 
            // ProcViagem_btn
            // 
            ProcViagem_btn.Location = new Point(587, 131);
            ProcViagem_btn.Name = "ProcViagem_btn";
            ProcViagem_btn.Size = new Size(243, 45);
            ProcViagem_btn.TabIndex = 8;
            ProcViagem_btn.Text = "Procurar Viagem";
            ProcViagem_btn.UseVisualStyleBackColor = true;
            ProcViagem_btn.Click += ProcViagem_btn_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.AccessibleRole = AccessibleRole.ButtonDropDown;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(56, 207);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.RowTemplate.Height = 33;
            dataGridView1.Size = new Size(774, 189);
            dataGridView1.TabIndex = 9;
            dataGridView1.CellContentClick += DataGridView1_CellContentClick;
            // 
            // dataGridViewBilhete
            // 
            dataGridViewBilhete.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewBilhete.Location = new Point(56, 426);
            dataGridViewBilhete.Name = "dataGridViewBilhete";
            dataGridViewBilhete.RowHeadersWidth = 62;
            dataGridViewBilhete.RowTemplate.Height = 33;
            dataGridViewBilhete.Size = new Size(774, 213);
            dataGridViewBilhete.TabIndex = 10;
            dataGridViewBilhete.CellContentClick += dataGridViewBilhete_CellContentClick;
            // 
            // viagens_label
            // 
            viagens_label.AutoSize = true;
            viagens_label.Location = new Point(56, 179);
            viagens_label.Name = "viagens_label";
            viagens_label.Size = new Size(74, 25);
            viagens_label.TabIndex = 11;
            viagens_label.Text = "Viagens";
            // 
            // BilhetesDisp_label
            // 
            BilhetesDisp_label.AutoSize = true;
            BilhetesDisp_label.Location = new Point(56, 399);
            BilhetesDisp_label.Name = "BilhetesDisp_label";
            BilhetesDisp_label.Size = new Size(168, 25);
            BilhetesDisp_label.TabIndex = 12;
            BilhetesDisp_label.Text = "Bilhetes Disponíveis";
            // 
            // FormProcViagem
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(890, 682);
            Controls.Add(BilhetesDisp_label);
            Controls.Add(viagens_label);
            Controls.Add(dataGridViewBilhete);
            Controls.Add(dataGridView1);
            Controls.Add(ProcViagem_btn);
            Controls.Add(Data_label);
            Controls.Add(dateTimePicker1);
            Controls.Add(viagemDe_label);
            Controls.Add(comboBox1);
            Controls.Add(Chegada_label);
            Controls.Add(textBox1);
            Controls.Add(Partida_label);
            Controls.Add(Partida_textBox);
            Margin = new Padding(4, 5, 4, 5);
            Name = "FormProcViagem";
            Text = "FormProcViagem";
            Load += FormProcViagem_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewBilhete).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox Partida_textBox;
        private Label Partida_label;
        private TextBox textBox1;
        private Label Chegada_label;
        private ComboBox comboBox1;
        private Label viagemDe_label;
        private DateTimePicker dateTimePicker1;
        private Label Data_label;
        private Button ProcViagem_btn;
        private DataGridView dataGridView1;
        private DataGridView dataGridViewBilhete;
        private Label viagens_label;
        private Label BilhetesDisp_label;
    }
}