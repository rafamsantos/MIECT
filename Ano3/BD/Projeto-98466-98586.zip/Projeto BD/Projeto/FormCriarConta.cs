﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;


namespace Projeto
{
    public partial class FormCriarConta : Form
    {
        public FormCriarConta()
        {
            InitializeComponent();
            FNameLabel.Visible = false;
            LNameLabel.Visible = false;
            AgeLabel.Visible = false;
            CCLabel.Visible = false;
            NIFLabel.Visible = false;
            UsernameLabel.Visible = false;
            PasswordLabel.Visible = false;
            TOSLabel.Visible = false;
        }

        private void FormCriarConta_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void CreateButton_Click(object sender, EventArgs e)
        {
            // Check if any field is empty
            bool empty = false;
            if (FNameBox.Text.Length == 0)
            {
                FNameLabel.Visible = true;
                empty = true;
            }
            if (LNameBox.Text.Length == 0)
            {
                LNameLabel.Visible = true;
                empty = true;
            }
            //convert age to int
            int age = 0;
            try
            {
                age = Convert.ToInt32(AgeBox.Text);
            }
            catch (FormatException)
            {
                AgeLabel.Visible = true;
                empty = true;
            }
            if (CCBox.Text.Length == 0)
            {
                CCLabel.Visible = true;
                empty = true;
            }
            if (NIFBox.Text.Length == 0)
            {
                NIFLabel.Visible = true;
                empty = true;
            }
            if (UsernameBox.Text.Length == 0)
            {
                UsernameLabel.Visible = true;
                empty = true;
            }
            if (PasswordBox.Text.Length == 0)
            {
                PasswordLabel.Visible = true;
                empty = true;
            }
            if (TOSradio.Checked == false)
            {
                TOSLabel.Visible = true;
                empty = true;
            }
            if (empty) return;

            string queryCreateClient = $"INSERT INTO Projeto.Passageiros (f_name, l_name, idade, cc, NIF, username, user_password, saldo) VALUES ('{FNameBox.Text}', '{LNameBox.Text}', {age}, '{CCBox.Text}', '{NIFBox.Text}', '{UsernameBox.Text}', '{PasswordBox.Text}', 0)";


            using (SqlConnection sqlconnection = new SqlConnection(GlobalVar.connection))
            {
                sqlconnection.Open();

                using (SqlCommand command = new SqlCommand(queryCreateClient, sqlconnection))
                {
                    int rowsAffected = command.ExecuteNonQuery();
                    // Verificar o número de linhas afetadas, se necessário
                    if (rowsAffected != 1)
                    {
                        MessageBox.Show("Erro ao criar conta.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
            }

            // show success message
            MessageBox.Show("Conta criada com sucesso.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //close form
            this.Close();
        }

        private void LNameLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
