﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto
{
    public partial class FormAdicionarDinheiro : Form
    {
        string username;
        public FormAdicionarDinheiro(string username)
        {
            InitializeComponent();
            this.username = username;
        }

        private void caregar_tbn_Click(object sender, EventArgs e)
        {
            // Verificar se o valor da saldoTextbox pode ser convertido para um número
            if (decimal.TryParse(saldoTextBox.Text, out decimal novoSaldo))
            {
                string query = $"SELECT saldo FROM Projeto.Passageiros WHERE username = '{this.username}'";

                string connection = "Data Source = tcp:mednat.ieeta.pt\\SQLSERVER,8101; Initial Catalog = p3g9; User ID = p3g9; Password =DR-777671364@BD";
                using (SqlConnection sqlconnection = new SqlConnection(connection))
                {
                    sqlconnection.Open();

                    using (SqlCommand command = new SqlCommand(query, sqlconnection))
                    {
                        SqlDataReader reader = command.ExecuteReader();
                        reader.Read();
                        double saldo = reader.GetDouble(0);
                        reader.Close();
                        novoSaldo += (int)saldo;
                    }
                }

                query = $"UPDATE Projeto.Passageiros SET saldo = {novoSaldo} WHERE username = '{this.username}'";

                connection = "Data Source = tcp:mednat.ieeta.pt\\SQLSERVER,8101; Initial Catalog = p3g9; User ID = p3g9; Password =DR-777671364@BD";
                using (SqlConnection sqlconnection = new SqlConnection(connection))
                {
                    sqlconnection.Open();

                    using (SqlCommand command = new SqlCommand(query, sqlconnection))
                    {
                        int rowsAffected = command.ExecuteNonQuery();
                        // Verificar o número de linhas afetadas, se necessário
                        if (rowsAffected > 1)
                        {
                            MessageBox.Show("Erro ao atualizar o saldo.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }
                }

                // Exibir uma mensagem de sucesso após a atualização
                MessageBox.Show("O saldo foi atualizado com sucesso.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            else
            {
                // Exibir uma mensagem de erro se o valor da saldoTextbox não for um número válido
                MessageBox.Show("Digite um valor numérico válido para o saldo.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormAdicionarDinheiro_Load(object sender, EventArgs e)
        {

        }
    }
}
