﻿namespace Projeto
{
    partial class FormLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            username_textBox = new TextBox();
            username_label = new Label();
            password_label = new Label();
            textBox1 = new TextBox();
            login_btn = new Button();
            CriarConta_btn = new Button();
            SuspendLayout();
            // 
            // username_textBox
            // 
            username_textBox.Location = new Point(296, 187);
            username_textBox.Margin = new Padding(4, 5, 4, 5);
            username_textBox.Name = "username_textBox";
            username_textBox.Size = new Size(254, 31);
            username_textBox.TabIndex = 0;
            username_textBox.TextChanged += username_textBox_TextChanged;
            // 
            // username_label
            // 
            username_label.AutoSize = true;
            username_label.Location = new Point(296, 157);
            username_label.Margin = new Padding(4, 0, 4, 0);
            username_label.Name = "username_label";
            username_label.Size = new Size(91, 25);
            username_label.TabIndex = 1;
            username_label.Text = "Username";
            // 
            // password_label
            // 
            password_label.AutoSize = true;
            password_label.Location = new Point(296, 290);
            password_label.Margin = new Padding(4, 0, 4, 0);
            password_label.Name = "password_label";
            password_label.Size = new Size(87, 25);
            password_label.TabIndex = 2;
            password_label.Text = "Password";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(296, 320);
            textBox1.Margin = new Padding(4, 5, 4, 5);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(254, 31);
            textBox1.TabIndex = 3;
            // 
            // login_btn
            // 
            login_btn.Location = new Point(340, 408);
            login_btn.Margin = new Padding(4, 5, 4, 5);
            login_btn.Name = "login_btn";
            login_btn.Size = new Size(149, 63);
            login_btn.TabIndex = 4;
            login_btn.Text = "Iniciar sessão";
            login_btn.UseVisualStyleBackColor = true;
            login_btn.Click += login_btn_Click;
            // 
            // CriarConta_btn
            // 
            CriarConta_btn.Location = new Point(344, 508);
            CriarConta_btn.Margin = new Padding(4, 5, 4, 5);
            CriarConta_btn.Name = "CriarConta_btn";
            CriarConta_btn.Size = new Size(144, 67);
            CriarConta_btn.TabIndex = 5;
            CriarConta_btn.Text = "Criar Conta";
            CriarConta_btn.UseVisualStyleBackColor = true;
            CriarConta_btn.Click += CriarConta_btn_Click;
            // 
            // FormLogin
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(890, 682);
            Controls.Add(CriarConta_btn);
            Controls.Add(login_btn);
            Controls.Add(textBox1);
            Controls.Add(password_label);
            Controls.Add(username_label);
            Controls.Add(username_textBox);
            Margin = new Padding(4, 5, 4, 5);
            Name = "FormLogin";
            Text = "FormLogin";
            Load += FormLogin_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox username_textBox;
        private Label username_label;
        private Label password_label;
        private TextBox textBox1;
        private Button login_btn;
        private Button CriarConta_btn;
    }
}