﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto
{
    public partial class FormPerfil : Form
    {
        // create initializer with username
        private string username;
        public FormPerfil(string name)
        {
            InitializeComponent();
            // store username
            this.username = name;
        }

        private void addSaldo_Click(object sender, EventArgs e)
        {
            FormAdicionarDinheiro formAdicionarDinheiro = new FormAdicionarDinheiro(username);
            formAdicionarDinheiro.Show();
        }

        private void FormPerfil_Load(object sender, EventArgs e)
        {

        }

        private void FormPerfil_Load_1(object sender, EventArgs e)
        {

        }
    }
}
