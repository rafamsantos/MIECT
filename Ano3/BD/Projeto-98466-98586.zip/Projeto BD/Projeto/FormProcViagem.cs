﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto
{
    public partial class FormProcViagem : Form
    {

        public event System.Windows.Forms.DataGridViewCellEventHandler CellContentClick;

        public FormProcViagem()
        {
            InitializeComponent();
        }

        private void Data_label_Click(object sender, EventArgs e)
        {

        }

        private void ProcViagem_btn_Click(object sender, EventArgs e)
        {
            DateTime dt = dateTimePicker1.Value;
            string dateTime = dt.ToString("dd-MM-yyyy");
            string partida = Partida_textBox.Text;
            string destino = textBox1.Text;

            string search_trip = $"SELECT * " +
               $"FROM Projeto.Viagem " +
               $"WHERE id IN ( " +
               $"    SELECT Projeto.Viagem.id " +
               $"    FROM Projeto.Viagem " +
               $"    JOIN Projeto.Paragens partida ON Viagem.id_partida = partida.id " +
               $"    JOIN Projeto.Paragens chegada ON Viagem.id_chegada = chegada.id " +
               $"    WHERE partida.nome = '{partida}' " +
               $"      AND chegada.nome = '{destino}' " +
               $")";


            using (SqlConnection sqlcon = new SqlConnection(GlobalVar.connection))
            {
                sqlcon.Open();
                SqlCommand sqlQuery = new SqlCommand(search_trip, sqlcon);

                SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlQuery);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);

                // Define o DataGridView como a fonte de dados
                dataGridView1.DataSource = dataTable;
                dataGridView1.CellClick += DataGridView1_CellContentClick;


            }

        }

        private void DataGridView1_CellContentClick(object? sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0) // Verifica se a célula clicada está em uma linha válida
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                string tripid = row.Cells["id"].Value.ToString();
                GlobalVar.ID = int.Parse(tripid);

                string query = $"SELECT Projeto.Bilhete.num_lugar,Projeto.Bilhete.id_viagem FROM Projeto.Bilhete WHERE id_viagem = {tripid} AND valid_flag = 0";

                using (SqlConnection sqlcon = new SqlConnection(GlobalVar.connection))
                {
                    sqlcon.Open();
                    SqlCommand sqlQuery = new SqlCommand(query, sqlcon);

                    SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlQuery);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    // Define o DataGridView como a fonte de dados
                    dataGridViewBilhete.DataSource = dataTable;
                    dataGridViewBilhete.CellClick += dataGridViewBilhete_CellContentClick;

                }


            }
        }

        private void FormProcViagem_Load(object sender, EventArgs e)
        {

        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridViewBilhete_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0) // Check if a valid cell is clicked
            {
                DataGridViewRow row = dataGridViewBilhete.Rows[e.RowIndex];

                string num_lugar = row.Cells["num_lugar"].Value.ToString();
                string id_viagem = row.Cells["id_viagem"].Value.ToString();


                // Show a message box with Yes/No options
                DialogResult result = MessageBox.Show("Deseja comprar este bilhete?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                // Check the user's selection
                if (result == DialogResult.Yes)
                {  
                    int id = GlobalVar.ID;
                    string username = GlobalVar.Username;
                    string notAnymoreBilhete = $"update Projeto.Bilhete set valid_flag= 1 where num_lugar ={num_lugar} and id_viagem={id_viagem};";
                    string addTicketPassenger = $"update Projeto.Passageiros set id_bilhete ={id} where Projeto.Passageiros.username = '{username}'";

                    using (SqlConnection sqlconnection = new SqlConnection(GlobalVar.connection))
                    {
                        sqlconnection.Open();

                        using (SqlCommand command = new SqlCommand(notAnymoreBilhete, sqlconnection))
                        {
                            int rowsAffected = command.ExecuteNonQuery();
                        }

                        using (SqlCommand command = new SqlCommand(addTicketPassenger, sqlconnection))
                        {
                            int rowsAffected = command.ExecuteNonQuery();
                        }
                        using (SqlCommand command = new SqlCommand(addTicketPassenger, sqlconnection))
                        {
                            int rowsAffected = command.ExecuteNonQuery();
                        }
                        sqlconnection.Close();

                        MessageBox.Show("O Bilhete foi comprado. Pode ter acesso ao bilhete na secção -Minhas Viagens-.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);


                    }

                    // TODO ::
                    // update table Passageiros , add id_bilhete
                }
                else if (result == DialogResult.No)
                {
                    MessageBox.Show("O bilhete NÃO foi comprado!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
            }

        }
    }
}
