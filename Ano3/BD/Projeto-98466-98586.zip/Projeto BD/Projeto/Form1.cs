namespace Projeto
{
    public partial class Form1 : Form
    {
        private Form frmAtivo;

        public string username = "";
        public Form1()
        {
            InitializeComponent();
        }

        public void UserName(string str)
        {
            this.username = str;
        }
        public void FormShow(Form frm)
        {
            ActiveFormClose();
            frmAtivo = frm;
            frm.TopLevel = false;
            painel_inicial.Controls.Add(frm);
            frm.BringToFront();
            frm.Show();
        }

        private void login_btn_Click(object sender, EventArgs e)
        {
            ActiveButton(login_btn);
            FormShow(new FormLogin(this));

        }

        private void procViagem_Click(object sender, EventArgs e)
        {
            ActiveButton(procViagem);
            FormShow(new FormProcViagem());

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void ActiveFormClose()
        {
            if (frmAtivo != null)
            {
                frmAtivo.Close();
            }
        }
        public void ActiveButton(Button fmrAtivo)
        {
            foreach (Control ctrl in painelPrincipal.Controls)
            {
                ctrl.ForeColor = Color.Black;

            }
            fmrAtivo.ForeColor = Color.Red;
        }

        private void MinhasViagens_bt_Click(object sender, EventArgs e)
        {
            ActiveButton(MinhasViagens_bt);
            FormShow(new FormMinhasViagens());
        }

        private void Perfil_bt_Click(object sender, EventArgs e)
        {
            ActiveButton(Perfil_bt);
            if (username == "")
            {
                // Show message saying that the user needs to login
                MessageBox.Show("Precisa de fazer login para aceder ao perfil");
                FormShow(new FormLogin(this));
            }
            else
            {
                FormShow(new FormPerfil(username));
            }
        }
    }
}