﻿namespace Projeto
{
    partial class FormCriarConta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            NIFBox = new TextBox();
            UsernameBox = new TextBox();
            AgeBox = new TextBox();
            LNameBox = new TextBox();
            FNameBox = new TextBox();
            PasswordBox = new TextBox();
            CCBox = new TextBox();
            CreateButton = new Button();
            TOSradio = new RadioButton();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            FNameLabel = new Label();
            LNameLabel = new Label();
            AgeLabel = new Label();
            CCLabel = new Label();
            NIFLabel = new Label();
            UsernameLabel = new Label();
            PasswordLabel = new Label();
            TOSLabel = new Label();
            SuspendLayout();
            // 
            // NIFBox
            // 
            NIFBox.Location = new Point(195, 195);
            NIFBox.Name = "NIFBox";
            NIFBox.Size = new Size(206, 23);
            NIFBox.TabIndex = 0;
            // 
            // UsernameBox
            // 
            UsernameBox.Location = new Point(195, 238);
            UsernameBox.Name = "UsernameBox";
            UsernameBox.Size = new Size(206, 23);
            UsernameBox.TabIndex = 1;
            UsernameBox.TextChanged += textBox2_TextChanged;
            // 
            // AgeBox
            // 
            AgeBox.Location = new Point(195, 103);
            AgeBox.Name = "AgeBox";
            AgeBox.Size = new Size(206, 23);
            AgeBox.TabIndex = 2;
            // 
            // LNameBox
            // 
            LNameBox.Location = new Point(195, 57);
            LNameBox.Name = "LNameBox";
            LNameBox.Size = new Size(206, 23);
            LNameBox.TabIndex = 3;
            // 
            // FNameBox
            // 
            FNameBox.Location = new Point(195, 14);
            FNameBox.Name = "FNameBox";
            FNameBox.Size = new Size(206, 23);
            FNameBox.TabIndex = 4;
            // 
            // PasswordBox
            // 
            PasswordBox.Location = new Point(195, 282);
            PasswordBox.Name = "PasswordBox";
            PasswordBox.PasswordChar = '*';
            PasswordBox.Size = new Size(206, 23);
            PasswordBox.TabIndex = 5;
            // 
            // CCBox
            // 
            CCBox.Location = new Point(195, 149);
            CCBox.Name = "CCBox";
            CCBox.Size = new Size(206, 23);
            CCBox.TabIndex = 6;
            // 
            // CreateButton
            // 
            CreateButton.Location = new Point(195, 366);
            CreateButton.Name = "CreateButton";
            CreateButton.Size = new Size(100, 41);
            CreateButton.TabIndex = 7;
            CreateButton.Text = "Criar Conta";
            CreateButton.UseVisualStyleBackColor = true;
            CreateButton.Click += CreateButton_Click;
            // 
            // TOSradio
            // 
            TOSradio.AutoSize = true;
            TOSradio.Location = new Point(195, 328);
            TOSradio.Name = "TOSradio";
            TOSradio.Size = new Size(361, 19);
            TOSradio.TabIndex = 9;
            TOSradio.TabStop = true;
            TOSradio.Text = "Concordo com a Política de Usuário* e os Termos e Condições*.";
            TOSradio.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(146, 17);
            label1.Name = "label1";
            label1.Size = new Size(43, 15);
            label1.TabIndex = 10;
            label1.Text = "Nome:";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(138, 60);
            label2.Name = "label2";
            label2.Size = new Size(51, 15);
            label2.TabIndex = 11;
            label2.Text = "Apelido:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(150, 106);
            label3.Name = "label3";
            label3.Size = new Size(39, 15);
            label3.TabIndex = 12;
            label3.Text = "Idade:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(131, 152);
            label4.Name = "label4";
            label4.Size = new Size(58, 15);
            label4.TabIndex = 13;
            label4.Text = "Nº CC/BI:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(161, 191);
            label5.Name = "label5";
            label5.Size = new Size(28, 15);
            label5.TabIndex = 14;
            label5.Text = "NIF:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(126, 244);
            label6.Name = "label6";
            label6.Size = new Size(63, 15);
            label6.TabIndex = 15;
            label6.Text = "Username:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(129, 276);
            label7.Name = "label7";
            label7.Size = new Size(60, 15);
            label7.TabIndex = 16;
            label7.Text = "Password:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 7F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(499, 394);
            label8.Name = "label8";
            label8.Size = new Size(113, 12);
            label8.TabIndex = 17;
            label8.Text = "*: ainda não foram feitos";
            // 
            // FNameLabel
            // 
            FNameLabel.AutoSize = true;
            FNameLabel.ForeColor = Color.Red;
            FNameLabel.Location = new Point(195, 39);
            FNameLabel.Name = "FNameLabel";
            FNameLabel.Size = new Size(93, 15);
            FNameLabel.TabIndex = 18;
            FNameLabel.Text = "Não tens nome?";
            // 
            // LNameLabel
            // 
            LNameLabel.AutoSize = true;
            LNameLabel.ForeColor = Color.Red;
            LNameLabel.Location = new Point(195, 83);
            LNameLabel.Name = "LNameLabel";
            LNameLabel.Size = new Size(142, 15);
            LNameLabel.TabIndex = 19;
            LNameLabel.Text = "O apelido, ficou em casa?";
            LNameLabel.Click += LNameLabel_Click;
            // 
            // AgeLabel
            // 
            AgeLabel.AutoSize = true;
            AgeLabel.ForeColor = Color.Red;
            AgeLabel.Location = new Point(195, 129);
            AgeLabel.Name = "AgeLabel";
            AgeLabel.Size = new Size(121, 15);
            AgeLabel.TabIndex = 20;
            AgeLabel.Text = "Olha o engraçadinho.";
            // 
            // CCLabel
            // 
            CCLabel.AutoSize = true;
            CCLabel.ForeColor = Color.Red;
            CCLabel.Location = new Point(113, 175);
            CCLabel.Name = "CCLabel";
            CCLabel.Size = new Size(511, 15);
            CCLabel.TabIndex = 21;
            CCLabel.Text = "O Furto de Identidade consiste na apropriação de identidade alheia ou de informações pessoais.";
            // 
            // NIFLabel
            // 
            NIFLabel.AutoSize = true;
            NIFLabel.ForeColor = Color.Red;
            NIFLabel.Location = new Point(74, 218);
            NIFLabel.Name = "NIFLabel";
            NIFLabel.Size = new Size(550, 15);
            NIFLabel.TabIndex = 22;
            NIFLabel.Text = "A fraude fiscal qualificada é um crime previsto no artigo 104º do Regime Geral das Infrações Tributárias.";
            // 
            // UsernameLabel
            // 
            UsernameLabel.AutoSize = true;
            UsernameLabel.ForeColor = Color.Red;
            UsernameLabel.Location = new Point(195, 264);
            UsernameLabel.Name = "UsernameLabel";
            UsernameLabel.Size = new Size(210, 15);
            UsernameLabel.TabIndex = 23;
            UsernameLabel.Text = "Tens de ter username, oh Zé Ninguém.";
            // 
            // PasswordLabel
            // 
            PasswordLabel.AutoSize = true;
            PasswordLabel.ForeColor = Color.Red;
            PasswordLabel.Location = new Point(195, 308);
            PasswordLabel.Name = "PasswordLabel";
            PasswordLabel.Size = new Size(132, 15);
            PasswordLabel.TabIndex = 24;
            PasswordLabel.Text = "Era só o que me faltava.";
            // 
            // TOSLabel
            // 
            TOSLabel.AutoSize = true;
            TOSLabel.ForeColor = Color.Red;
            TOSLabel.Location = new Point(195, 348);
            TOSLabel.Name = "TOSLabel";
            TOSLabel.Size = new Size(79, 15);
            TOSLabel.TabIndex = 25;
            TOSLabel.Text = "Boa tentativa.";
            // 
            // FormCriarConta
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(624, 415);
            Controls.Add(TOSLabel);
            Controls.Add(PasswordLabel);
            Controls.Add(UsernameLabel);
            Controls.Add(NIFLabel);
            Controls.Add(CCLabel);
            Controls.Add(AgeLabel);
            Controls.Add(LNameLabel);
            Controls.Add(FNameLabel);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(TOSradio);
            Controls.Add(CreateButton);
            Controls.Add(CCBox);
            Controls.Add(PasswordBox);
            Controls.Add(FNameBox);
            Controls.Add(LNameBox);
            Controls.Add(AgeBox);
            Controls.Add(UsernameBox);
            Controls.Add(NIFBox);
            Margin = new Padding(2);
            Name = "FormCriarConta";
            Text = "FormCriarConta";
            Load += FormCriarConta_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox NIFBox;
        private TextBox UsernameBox;
        private TextBox AgeBox;
        private TextBox LNameBox;
        private TextBox FNameBox;
        private TextBox PasswordBox;
        private TextBox CCBox;
        private Button CreateButton;
        private RadioButton TOSradio;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label FNameLabel;
        private Label LNameLabel;
        private Label AgeLabel;
        private Label CCLabel;
        private Label NIFLabel;
        private Label UsernameLabel;
        private Label PasswordLabel;
        private Label TOSLabel;
    }
}