﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.ComponentModel.Design.ObjectSelectorEditor;

namespace Projeto
{

    public partial class FormMinhasViagens : Form
    {
        public FormMinhasViagens()
        {
            InitializeComponent();

        }

        private void FormMinhasViagens_Load(object sender, EventArgs e)
        {
            string username = GlobalVar.Username;
            string my_tickets = $"Select Projeto.Viagem.id,Projeto.Viagem.preço,Projeto.Bilhete.num_lugar ,Projeto.Viagem.id_veiculo,Projeto.Viagem.Hora, Projeto.Viagem.hora_chegada \r\nfrom Projeto.Viagem\r\njoin Projeto.Bilhete on Projeto.Bilhete.id_viagem = Projeto.Viagem.id \r\njoin Projeto.Passageiros on Projeto.Passageiros.id_bilhete = Projeto.Bilhete.id\r\n where Projeto.Passageiros.username = '{username}'";

            SqlConnection sqlcon = new SqlConnection(GlobalVar.connection);
            sqlcon.Open();
            SqlDataAdapter sqlDAdapter = new SqlDataAdapter(my_tickets, sqlcon);
            DataTable dTbl = new DataTable();
            sqlDAdapter.Fill(dTbl);

            // Bind the data to the DataGridView control
            dataGridViewMinhasViagens.DataSource = dTbl;
            dataGridViewMinhasViagens.CellClick += dataGridViewMinhasViagens_CellContentClick;


            sqlcon.Close();



        }


        private void dataGridViewMinhasViagens_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
