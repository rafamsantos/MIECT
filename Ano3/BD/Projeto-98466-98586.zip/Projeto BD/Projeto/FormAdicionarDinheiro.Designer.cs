﻿namespace Projeto
{
    partial class FormAdicionarDinheiro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            saldoTextBox = new TextBox();
            carregar_label = new Label();
            caregar_tbn = new Button();
            SuspendLayout();
            // 
            // saldoTextBox
            // 
            saldoTextBox.Location = new Point(330, 183);
            saldoTextBox.Margin = new Padding(4, 5, 4, 5);
            saldoTextBox.Name = "saldoTextBox";
            saldoTextBox.Size = new Size(197, 31);
            saldoTextBox.TabIndex = 0;
            // 
            // carregar_label
            // 
            carregar_label.AutoSize = true;
            carregar_label.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            carregar_label.Location = new Point(341, 137);
            carregar_label.Margin = new Padding(4, 0, 4, 0);
            carregar_label.Name = "carregar_label";
            carregar_label.Size = new Size(190, 38);
            carregar_label.TabIndex = 1;
            carregar_label.Text = "Carregar com:";
            // 
            // caregar_tbn
            // 
            caregar_tbn.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            caregar_tbn.Location = new Point(330, 282);
            caregar_tbn.Margin = new Padding(4, 5, 4, 5);
            caregar_tbn.Name = "caregar_tbn";
            caregar_tbn.Size = new Size(199, 63);
            caregar_tbn.TabIndex = 2;
            caregar_tbn.Text = "Carregar";
            caregar_tbn.UseVisualStyleBackColor = true;
            caregar_tbn.Click += caregar_tbn_Click;
            // 
            // FormAdicionarDinheiro
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(891, 692);
            Controls.Add(caregar_tbn);
            Controls.Add(carregar_label);
            Controls.Add(saldoTextBox);
            Margin = new Padding(4, 5, 4, 5);
            Name = "FormAdicionarDinheiro";
            Text = "FormAdicionarDinheiro";
            Load += FormAdicionarDinheiro_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox saldoTextBox;
        private Label carregar_label;
        private Button caregar_tbn;
    }
}