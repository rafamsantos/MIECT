﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto
{
    public partial class FormBilhetes : Form
    {
        public FormBilhetes()
        {
            InitializeComponent();
        }

        private void FormBilhetes_Load(object sender, EventArgs e)
        {

        }

        private void ver_bilhetes_btn_Click(object sender, EventArgs e)
        {
            
            string searchBilhetes = "Select Projeto.Bilhete.num_lugar from Projeto.Bilhete\r\njoin Projeto.Viagem on Projeto.Viagem.id = Projeto.Bilhete.id_viagem\r\nwhere Projeto.Bilhete.valid_flag = '0' and Projeto.Bilhete.id_viagem = @tripid;";
            string connection = "Data Source = tcp: mednat.ieeta.pt\\SQLSERVER, 8101; Initial Catalog = p3g9; User ID = p3g9; Password =DR-777671364@BD";

            using (SqlConnection sqlcon = new SqlConnection(connection))
            {
                sqlcon.Open();
                SqlCommand sqlQuery = new SqlCommand(searchBilhetes, sqlcon);

                SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlQuery);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);

                // Define o DataGridView como a fonte de dados
                dataGridViewBilhetes.DataSource = dataTable;
                dataGridViewBilhetes.CellClick += dataGridViewBilhetes_CellContentClick;


            }

        }

        private void dataGridViewBilhetes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
