﻿namespace Projeto
{
    partial class FormMinhasViagens
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewMinhasViagens = new DataGridView();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridViewMinhasViagens).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewMinhasViagens
            // 
            dataGridViewMinhasViagens.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewMinhasViagens.Location = new Point(135, 126);
            dataGridViewMinhasViagens.Name = "dataGridViewMinhasViagens";
            dataGridViewMinhasViagens.RowHeadersWidth = 62;
            dataGridViewMinhasViagens.RowTemplate.Height = 33;
            dataGridViewMinhasViagens.Size = new Size(689, 428);
            dataGridViewMinhasViagens.TabIndex = 0;
            dataGridViewMinhasViagens.CellContentClick += dataGridViewMinhasViagens_CellContentClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(279, 58);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(349, 54);
            label1.TabIndex = 1;
            label1.Text = "As minhas viagens";
            // 
            // FormMinhasViagens
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(890, 682);
            Controls.Add(label1);
            Controls.Add(dataGridViewMinhasViagens);
            Name = "FormMinhasViagens";
            Text = "FormMinhasViagens";
            Load += FormMinhasViagens_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewMinhasViagens).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridViewMinhasViagens;
        private Label label1;
    }
}