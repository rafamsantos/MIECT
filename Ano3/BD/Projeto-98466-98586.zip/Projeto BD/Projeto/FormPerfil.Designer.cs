﻿namespace Projeto
{
    partial class FormPerfil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Perfil_label = new Label();
            alterarNome_bt = new Button();
            alterarPass_bt = new Button();
            AlterarNIF_bt = new Button();
            AlterarIdade_bt = new Button();
            addSaldo = new Button();
            SuspendLayout();
            // 
            // Perfil_label
            // 
            Perfil_label.AutoSize = true;
            Perfil_label.Font = new Font("Segoe UI", 25F, FontStyle.Regular, GraphicsUnit.Point);
            Perfil_label.Location = new Point(376, 65);
            Perfil_label.Name = "Perfil_label";
            Perfil_label.Size = new Size(138, 67);
            Perfil_label.TabIndex = 0;
            Perfil_label.Text = "Perfil";
            // 
            // alterarNome_bt
            // 
            alterarNome_bt.Location = new Point(313, 283);
            alterarNome_bt.Name = "alterarNome_bt";
            alterarNome_bt.Size = new Size(251, 68);
            alterarNome_bt.TabIndex = 1;
            alterarNome_bt.Text = "Alterar Nome";
            alterarNome_bt.UseVisualStyleBackColor = true;
            // 
            // alterarPass_bt
            // 
            alterarPass_bt.Location = new Point(313, 358);
            alterarPass_bt.Name = "alterarPass_bt";
            alterarPass_bt.Size = new Size(251, 68);
            alterarPass_bt.TabIndex = 2;
            alterarPass_bt.Text = "Alterar Password";
            alterarPass_bt.UseVisualStyleBackColor = true;
            // 
            // AlterarNIF_bt
            // 
            AlterarNIF_bt.Location = new Point(313, 433);
            AlterarNIF_bt.Name = "AlterarNIF_bt";
            AlterarNIF_bt.Size = new Size(251, 68);
            AlterarNIF_bt.TabIndex = 3;
            AlterarNIF_bt.Text = "Alterar NIF";
            AlterarNIF_bt.UseVisualStyleBackColor = true;
            // 
            // AlterarIdade_bt
            // 
            AlterarIdade_bt.Location = new Point(313, 508);
            AlterarIdade_bt.Name = "AlterarIdade_bt";
            AlterarIdade_bt.Size = new Size(251, 68);
            AlterarIdade_bt.TabIndex = 4;
            AlterarIdade_bt.Text = "Alterar idade";
            AlterarIdade_bt.UseVisualStyleBackColor = true;
            // 
            // addSaldo
            // 
            addSaldo.Location = new Point(313, 207);
            addSaldo.Margin = new Padding(4, 5, 4, 5);
            addSaldo.Name = "addSaldo";
            addSaldo.Size = new Size(251, 68);
            addSaldo.TabIndex = 5;
            addSaldo.Text = "Adicionar fundos";
            addSaldo.UseVisualStyleBackColor = true;
            addSaldo.Click += addSaldo_Click;
            // 
            // FormPerfil
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(891, 692);
            Controls.Add(addSaldo);
            Controls.Add(AlterarIdade_bt);
            Controls.Add(AlterarNIF_bt);
            Controls.Add(alterarPass_bt);
            Controls.Add(alterarNome_bt);
            Controls.Add(Perfil_label);
            Name = "FormPerfil";
            Text = "FormPerfil";
            Load += FormPerfil_Load_1;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Perfil_label;
        private Button alterarNome_bt;
        private Button alterarPass_bt;
        private Button AlterarNIF_bt;
        private Button AlterarIdade_bt;
        private Button addSaldo;
    }
}