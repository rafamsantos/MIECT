Link video promocional(dropbox): 

https://www.dropbox.com/scl/fo/2co61woyxt125f8mkqf54/AGNRfnnRFAaQh7YEO5-aM7E?rlkey=1x2n2wgcf54y6hco969hdh8zz&st=b73y9csi&dl=0


Link website: https://rafamsantos.github.io/PECI.github.io/

Link website -github: https://github.com/rafamsantos/PECI.github.io


Link repositório github: https://github.com/rafamsantos/PECI