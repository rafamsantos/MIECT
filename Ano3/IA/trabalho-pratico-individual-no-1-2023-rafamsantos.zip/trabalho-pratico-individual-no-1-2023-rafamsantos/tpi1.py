from tree_search import *
from cidades import *
from blocksworld import *


def func_branching(connections,coordinates):
    # children list
    children = []   # list of children
    for coor in coordinates:    # for each coordinate
        for (c1,c2,d) in connections:   # for each connection
            if c1 == coor:  # if the first coordinate is the same as the current coordinate
                children.append(c2) # add the second coordinate to the children list
            elif c2 == coor:    # if the second coordinate is the same as the current coordinate
                children.append(c1) # add the first coordinate to the children list 
    children_sum = len(children)    # number of children
    average_branching_factor = children_sum / len(coordinates)    # average branching factor

    return average_branching_factor-1
    

class MyCities(Cidades):
    def __init__(self,connections,coordinates):
        super().__init__(connections,coordinates)
        self.average_branching_factor = func_branching(connections,coordinates) # add the average branching factor to the domain
        

class MySTRIPS(STRIPS):
    def __init__(self,optimize=False):
        super().__init__(optimize)

    def simulate_plan(self,state,plan): 
        for act in plan: # for each action in the plan
            # computes the final state after the plan is fully executed
            state = self.result(state,act) # update the state
            
        return state # return the final state

 
class MyNode(SearchNode):
    def __init__(self,state,parent,depth,cost,heuristic):
        super().__init__(state,parent)
        self.cost =cost
        self.heuristic = heuristic
        self.depth = depth
        

class MyTree(SearchTree):   

    def __init__(self,problem, strategy='breadth',optimize=0,keep=0.25): 
        super().__init__(problem,strategy) 
        
        root = MyNode(problem.initial,None,0,0,problem.domain.heuristic(problem.initial,problem.goal)) # create the root node
        self.all_nodes = [root]
        self.optimize = optimize;   
        self.keep = keep    # 
        self.p_as_tuple = problem # problem as tuple    
        self.initial= problem.initial # initial state
        self.goal = problem.goal # goal state       

    def astar_add_to_open(self,lnewnodes): # adds new node to the queue according to a* criteria and works for every strategy
        if self.optimize == 0:  # if the optimization is 0
            self.open_nodes.extend(lnewnodes) # add the new nodes to the open nodes list
        elif self.optimize == 1:    # if the optimization is 1
            self.open_nodes.extend(lnewnodes) # add the new nodes to the open nodes list as tuples
            self.open_nodes.sort(key=lambda x: x.cost + x.heuristic) # sort the open nodes list by the cost and heuristic
        return self.open_nodes
       
    # remove a fraction of open (terminal) nodes
    # with lowest evaluation function
    # (used in Incrementally Bounded A*)
    def forget_worst_terminals(self):
        
        astar_scores = [] # list of scores
        for s in self.all_nodes:
            astar_scores[s] = s.cost + s.heuristic
        #remove the worst nodes
        for i in astar_scores: # for each score
            max_nodes_given_depth = self.problem.domain.average_branching_factor ** i.depth # max nodes given depth
            # cumpute using the branching factor
            NumKeep = round(int(self.keep * max_nodes_given_depth),1) # number of nodes to keep 
            if i > NumKeep: # if the score is greater than NumKeep 
                self.open_nodes.remove(i) # remove the node from the open nodes list
                self.all_nodes.remove(i) # remove the node from the all nodes list
        return self.open_nodes # return the open nodes list
        

    # procurar a solucao
    def search2(self): # optimized search supporting tuples
        
        while self.open_nodes != []: # while there are open nodes
            nodeID = self.open_nodes.pop(0) # get the first node
            node = self.all_nodes[nodeID] # get the node
            tuple_state = (node.state,node.depth,node.cost,node.heuristic) # tuple state
            tuple_domain = (func_actions,func_result,func_cost,func_heuristic,func_satisfies,self.problem.domain.average_branching_factor) # tuple domain
            p_as_tuple = (tuple_domain, self.initial, self.goal) # problem as tuple
            
            if self.problem.goal_test(node.state): # if the node is the goal
                #if self.optimize == 1: # if the problem is optimized
                #    self.solution=tuple_state
                if self.optimize == 1: # node represented as tuple
                    self.solution= tuple_state
                #if self.optimize == 2: # nodes and domains are represented as tuple
                #    self.solution = p_as_tuple
                else: # if the problem isnt optimized
                    self.solution = node # set the solution to the node
                self.terminals = len(self.open_nodes)+1 # set the number of terminals
                return self.get_path(node) # return the path
            lnewnodes = [] # list of new nodes
            self.non_terminals += 1 # increment the number of non terminals
            for a in self.problem.domain.actions(node.state): # for each action in the domain
                #newstate = self.problem.domain.result(tuple_state,a) # get the new state
                newstate = self.problem.domain.result(node.state,a) # get the new state
                if newstate not in self.get_path(node): # if the new state is not in the path
                    newnode = MyNode(newstate,nodeID,node.depth+1,node.cost+self.problem.domain.cost(node.state,a),self.problem.domain.heuristic(newstate,self.problem.goal)) # create a new node
                    lnewnodes.append(len(self.all_nodes)) # add the new node to the list of new nodes
                    self.all_nodes.append(newnode) # add the new node to the list of all nodes
                
            self.add_to_open(lnewnodes) # add the new nodes to the open nodes list
        return None

# If needed, auxiliary functions can be added




