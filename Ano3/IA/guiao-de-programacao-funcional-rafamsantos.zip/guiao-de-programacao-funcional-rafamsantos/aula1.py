# Exercicio 1.1
from unittest import result


def comprimento(lista):
    if not lista:
        return 0
    return 1 + comprimento(lista[1:])


# Exercicio 1.2
def soma(lista):
    if lista == []:
        return 0
    return lista[0]+soma(lista[1:])


# Exercicio 1.3
def existe(lista, elem):
    if lista == []:
        return False
    if lista[0] == elem:
        return True
    return existe(lista[1:], elem)


# Exercicio 1.4
def concat(l1, l2):
    if(l2 == []):
        return l1[:]
    # res é uma list de tamanho len(l1)+(len(l2)-1) onde ja se encontra o conteudo de l1
    res = concat(l1, l2[0:len(l2)-1])
    res.append(l2[len(l2)-1])    # é adicionado à lista o conteudo de l2
    return res


#Exercicio 1.5
def inverte(lista):
    if lista == []:
        return []
    inv = inverte(lista[1:])    # inverte a lista
    inv[len(inv):] = [lista[0]] # coloca o 1º elemento no fim
    return inv

#Exercicio 1.6
def capicua(lista):
    if lista == []:
        return True
    return lista[0] == lista[len(lista)-1] and capicua(lista[1:len(lista)-1])

#Exercicio 1.7
def explode(lista):
    if lista == []:
        return []
    concLista = explode(lista[:len(lista)-1])
    concLista += lista[len(lista)-1]
    return concLista

	

#Exercicio 1.8
def substitui(lista, original, novo):
    if lista == []:
        return []
    res = substitui(lista[:len(lista)-1], original, novo)
    if(lista[len(lista)-1] == original):
        res[len(lista)-1:] = [novo]
    else:
        res[len(lista)-1:] = [lista[len(lista)-1]]
    return res

#Exercicio 1.9
def junta_ordenado(lista1, lista2):
    union = [] # lista que vai conter a união das duas listas

    if lista1 == [] and lista2 != []:
        return lista2;
    if lista2 == [] and lista1 != []:
        return lista1;
    if lista1 ==[] and lista2 == []:
        return []

    if(lista1[0] <= lista2[0]):
        union.append(lista1[0])
        union += junta_ordenado(lista1[1:], lista2)
    if(lista1[0]> lista2[0]):
        union.append(lista2[0])
        union += junta_ordenado(lista1, lista2[1:])
        
    return union
    


#Exercicio 2.1
def separar(lista):
    if lista == []:
        return ([],[])

    res = separar(lista[0:len(lista)-1])
    res[0].append(lista[len(lista)-1][0])
    res[1].append(lista[len(lista)-1][1])
    return res

#Exercicio 2.2
def remove_e_conta(lista, elem):
    
    count=0
    if lista == []:
        return ([],0)
    
    if(elem == lista[0]):
        count = 1 + remove_e_conta(lista[1:],elem);
        
    else:
        return remove_e_conta(lista[1:], count)
    
   

    


#Exercicio 3.1
def cabeca(lista):
    if lista == []:
        return []
    return lista[0]

#Exercicio 3.2
def cauda(lista):
    if lista == []:
        return []

    return cauda(lista[1:])


#Exercicio 3.3
def juntar(l1 , l2):
    if(len(l1)!=len(l2)):
        return None
    elif(l1 == [] and l2 == []):
        return [];

    result = juntar(l1[0:len(l1)-1], l2[0:len(l2)-1])
    result.append((l1[len(l1)-1], l2[len(l2)-1]))
    return result

#Exercicio 3.4
def menor(lista):
	pass

#Exercicio 3.6
def max_min(lista):
	pass
