

# Guiao de representacao do conhecimento
# -- Redes semanticas
# 
# Inteligencia Artificial & Introducao a Inteligencia Artificial
# DETI / UA
#
# (c) Luis Seabra Lopes, 2012-2020
# v1.9 - 2019/10/20
#


# Classe Relation, com as seguintes classes derivadas:
#     - Association - uma associacao generica entre duas entidades
#     - Subtype     - uma relacao de subtipo entre dois tipos
#     - Member      - uma relacao de pertenca de uma instancia a um tipo
#

class Relation:
    def __init__(self,e1,rel,e2):
        self.entity1 = e1
#       self.relation = rel  # obsoleto
        self.name = rel
        self.entity2 = e2
    def __str__(self):
        return self.name + "(" + str(self.entity1) + "," + \
               str(self.entity2) + ")"
    def __repr__(self):
        return str(self)
    
class AssocOne(Relation):
    def __init__(self,e1,rel,e2):
        Relation.__init__(self,e1,rel,e2)

class AssocNum(Relation):
    def __init__(self,e1,rel,e2):
        Relation.__init__(self,e1,rel,e2)


# Subclasse Association
class Association(Relation):
    def __init__(self,e1,assoc,e2):
        Relation.__init__(self,e1,assoc,e2)

#   Exemplo:
#   a = Association('socrates','professor','filosofia')

# Subclasse Subtype
class Subtype(Relation):
    def __init__(self,sub,super):
        Relation.__init__(self,sub,"subtype",super)


#   Exemplo:
#   s = Subtype('homem','mamifero')

# Subclasse Member
class Member(Relation):
    def __init__(self,obj,type):
        Relation.__init__(self,obj,"member",type)

#   Exemplo:
#   m = Member('socrates','homem')

# classe Declaration
# -- associa um utilizador a uma relacao por si inserida
#    na rede semantica
#
class Declaration:
    def __init__(self,user,rel):
        self.user = user
        self.relation = rel
    def __str__(self):
        return "decl("+str(self.user)+","+str(self.relation)+")"
    def __repr__(self):
        return str(self)

#   Exemplos:
#   da = Declaration('descartes',a)
#   ds = Declaration('darwin',s)
#   dm = Declaration('descartes',m)


# classe SemanticNetwork
# -- composta por um conjunto de declaracoes
#    armazenado na forma de uma lista
#
class SemanticNetwork:
    def __init__(self,ldecl=None):
        self.declarations = [] if ldecl==None else ldecl
    def __str__(self):
        return str(self.declarations)
    def insert(self,decl):
        self.declarations.append(decl)
    def query_local(self,user=None,e1=None,rel=None,e2=None):
        self.query_result = \
            [ d for d in self.declarations
                if  (user == None or d.user==user)
                and (e1 == None or d.relation.entity1 == e1)
                and (rel == None or d.relation.name == rel)
                and (e2 == None or d.relation.entity2 == e2) ]
        return self.query_result
    def show_query_result(self):
        for d in self.query_result:
            print(str(d))

    #ex1
    def list_associations(self):
        l = set()
        for a in self.declarations:
            if isinstance(a.relation, Association):
                l.add(a.relation.name)
        return l
    #ex2
    def list_objects(self):
        l = set()
        for a in self.declarations: 
            if isinstance(a.relation, Member): 
                l.add(a.relation.entity1) 
        return l
    #ex3
    def list_users(self):
        l = set()
        for a in self.declarations:
            l.add(a.user)
        return l
    #ex4
    def list_types(self):
        return list(set([d.relation.entity1 for d in self.declarations if isinstance(d.relation, Subtype)]+
            [d.relation.entity2 for d in self.declarations if isinstance(d.relation, Subtype) 
            or isinstance(d.relation , Member)]))
    #ex5
    def list_local_associations(self, entity):
        l = set()
        for a in self.declarations: # 
            if isinstance(a.relation, Association) and a.relation.entity1 == entity: 
                l.add(a.relation.name)
        return l
    #ex6
    def list_relations_by_user(self, user):
        l = set()
        for a in self.declarations: # 
            if a.user == user: #  
                l.add(a.relation.name) #
        return l

    #ex7
    def associations_by_user(self, user):
        l = set()
        for a in self.declarations:
            if a.user == user:
                if isinstance(a.relation, Association):
                    l.add(a.relation.name)
        return len(l)
    #ex8
    def list_local_associations_by_user(self, entity):
        return list(set([(d.relation.name, d.user) for d in self.declarations if d.relation.entity1 == entity and isinstance(d.relation, Association) ]))
    #ex9
    def predecessor(self, A,B):
        direct_predecessors = [d.relation.entity2 for d in self.declarations if d.relation.entity1 == B \
            and (isinstance(d.relation, Subtype) or isinstance(d.relation, Member))] # direct predecessors
        
        # if A is a direct predecessor of B return True
        if A in direct_predecessors:
            return True

        # now, check if A is an indirect predecessor of B
        for pred in direct_predecessors: # for each direct predecessor of B
            if self.predecessor(A, pred): # check if A is a predecessor of that predecessor
                return True # if so, return True
        
        return False

    #ex10
    def predecessor_path(self, A, B):
        direct_predecessors = [d.relation.entity2 for d in self.declarations if d.relation.entity1 == B \
            and (isinstance(d.relation, Subtype) or isinstance(d.relation, Member))]

        # if A is a direct predecessor of B return True
        if A in direct_predecessors:
            return [A,B]; #

        for pred in direct_predecessors: # for each predecessor
            path = self.predecessor_path(A, pred)  # path = caminho entre A e pred
            if path != None:
                return path + [B];

        return None
        


    #ex11-a)
    def query(self,entity, assocname = None):
        direct_predecessors = [d.relation.entity2 for d in self.declarations if d.relation.entity1 == entity \
            and (isinstance(d.relation, Subtype) or isinstance(d.relation, Member))]

        decLocal = [d for d in self.query_local(e1 = entity, rel = assocname) if isinstance(d.relation, Association)]

        for p in direct_predecessors: # for each predecessor
            decLocal += self.query(p, assocname) # query the predecessor
            # if the predecessor has the association, return True

        return decLocal
    #ex11-b)
    def query2(self,entity, relName = None):
        query_result = self.query(entity); # goes for local declarations(Member and subtype, nao herdadas)
        
        ldeclarations = self.query_local(e1=entity) # 
        lassoc = [ d for d in ldeclarations if not isinstance(d.relation, Association) 
                                            and (d.relation.name == relName or relName == None) ]

        return query_result + lassoc

        
    #ex12
    def query_cancel(self, entity, assocname = None):
        
        ldeclarations = self.query_local(e1=entity) # goes for local declarations(Member and subtype, nao herdadas)
        
        direct_predecessors = [d.relation.entity2 for d in ldeclarations if not isinstance(d.relation, Association)]; # direct predecessors
        lassoc = [ d for d in ldeclarations if isinstance(d.relation, Association) and (d.relation.name == assocname)] # local associations

        if lassoc == []:    # if there are no local associations
            for p in direct_predecessors:   # for each predecessor
                lassoc += self.query_cancel(p, assocname)   # query the predecessor
                # if the predecessor has the association, return True
        return lassoc

    #ex13
    def query_down(self, e, rel = None, child = None): # return a list with all declarations of an association of sucessors
        
       # 1 - find direct descendants
        direct_descendants = [d.relation.entity1 for d in self.declarations if
                              d.relation.entity2 == e
                              and
                              (isinstance(d.relation, Subtype) or isinstance(d.relation, Member))]

        decl = []   # list of declarations is empty because we are going to fill it
        if not child: # if child is not defined
            decl += [d for d in self.query_local(e1=e, rel=rel) if isinstance(d.relation, Association)] # add local declarations

        # now, get the inherited declarations
        for desc in direct_descendants: # for each descendant
            decl += self.query_down(desc, rel, False) # query the descendant

        return decl
    # ex14
    def query_induce(self, entity, assocname = None):
        descendants_declarations = self.query_down(entity, assocname) # get all declarations of the association of the descendants

        dec_count = {} # dictionary to count the number of declarations of each entity

        for d in descendants_declarations: # for each declaration
            if d.relation.entity1 in dec_count: # if the entity is already in the dictionary
                dec_count[d.relation.entity2] += 1 # increment the number of declarations
            
            else: # if the entity is not in the dictionary
                dec_count[d.relation.entity2] = 1 # add the entity to the dictionary with 1 declaration

        # return the value with the most declarations
        return max(dec_count, key=dec_count.get)

    # ex15
    def query_local_assoc()
        



    