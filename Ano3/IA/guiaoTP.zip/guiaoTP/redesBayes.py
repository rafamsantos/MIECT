# variaveis
# CP - cara de preocupado
# FER - frequencia exagerada do rato
# ST - sobrecarga de trabalho - (independente)
# CENL - correio eletronico nao lido
# UPT - usando o processador por texto(independente)
# PA - precisa de ajuda

# topologia da rede

#      UPT   ST____                 
#     /   \    \   \              
#    |  ___PA   \   CENL
#    | /    \    \
#   FER      \___CP

# P(FER|UPT, PA)= 0.90 
# P(FER|~UPT, PA)= 0.10
# P(FER|UPT, ~PA)= 0.90
# P(FER|~UPT, ~PA)= 0.01

# P(CP| PA, ST) = 0.02
# P(CP| PA, ~ST) = 0.01
# P(CP| ~PA, ST) = 0.001
# P(CP| ~PA, ~ST) = 0.011

# P(PA| UPT) =  0.25
# P(PA| ~UPT) = 0.004

# P(CNTL, ST) = 0.90
# P(CNTL, ~ST) = 0.001

#P(UPT) = 0.05

# P(ST) = 0.60