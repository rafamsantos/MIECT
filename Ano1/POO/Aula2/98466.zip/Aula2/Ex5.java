package Aula2;
import java.util.Scanner;
public class Ex5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Velocidade Trajeto 1 : ");
        double v1 = sc.nextDouble();
        System.out.println("Distância Trajeto 1 : ");
        double d1 = sc.nextDouble();
        System.out.println("Velocidade Trajeto 2 : ");
        double v2 = sc.nextDouble();
        System.out.println("Distância Trajeto 2 : ");
        double d2 = sc.nextDouble();

        double vf = 0;
        System.out.println("Velocidade média final trajeto : "+vf);

        sc.close();

    }
    
}
