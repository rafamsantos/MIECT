package Aula6;

import Aula5.ex1.*;

public class Pessoa {
    private String nome;
    private int cc;
    private Date dataNasc;

    public Pessoa(String nome , int cc , Date dataNasc){
        this.nome = nome;
        this.cc = cc;
        this.dataNasc = dataNasc;
    }
    public Pessoa(String nome , Date dataNasc){
        this.nome = nome;
        this.dataNasc = dataNasc;
    }
    public Pessoa(String nome ){
        this.nome = nome;
    }
    public String getName(){return this.nome;}

    public int getCC(){return this.cc;}

    public Date getDataNAsc(){return this.dataNasc;}

    public void setNome(String nome){this.nome = nome;}

    public void setCC(int cc){this.cc = cc;}

    public void setDataNasc(Date dataNasc){this.dataNasc = dataNasc;}

    @Override
    public String toString(){
        return getName() +" ; Data de Nascimento: "+getDataNAsc();
    }
    
}
