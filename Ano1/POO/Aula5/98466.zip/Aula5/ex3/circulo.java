package Aula5.ex3;

public class circulo {
    private double raio;

    public circulo(double raio){
        this.raio = raio;
    }
    public void setCirculo(double raio){
        this.raio = raio;
    }
    public double getRaio(){
        return raio;
    }
    public void setRaio(double raio){
        this.raio = raio;
    }
    public double getArea(){
        return Math.PI*raio*raio;
    }
    public double getPerimetro(){
        return Math.PI*2*raio;
    }
}
