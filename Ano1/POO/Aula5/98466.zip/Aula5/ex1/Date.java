package Aula5.ex1;
import java.util.*;


public class Date {
    private int year;
    private int month;
    private int day;
    static Scanner x = new Scanner(System.in);

    public Date(int year , int month ,int day){
        this.year =year;
        this.month = month;
        this.day =day;

    }
    public int getYear(){return this.year;}
    public int getMonth(){return this.month;}
    public int getDay(){return this.day;}
    public void setYear(int year){ this.year = year;}
    public void setMonth(int month){ this.month = month;}
    public void setDay(int day){ this.day = day;}

   /* public void inc(int day , int month , int year){
        if( day > 0 && day < monthDays(month, year)){   // dia a meio do mês
            day = day+1;
        }else if(day == monthDays(month, year)&& month != 12){  // ultimo dia de um mes que nao seja Dezembro
            day = 1;
            month+=1;
        }else if(day == monthDays(month, year) && month == 12){
            day = 1;
            month =1;
            year+=1;
        }
    }
    public void dec(int day , int month , int year){
        if( day > 1 && day < monthDays(month, year)){   // dia a meio do mês
            day -=1;
        }else if(day == 1 && month != 1){  // ultimo dia de um mes que nao seja Dezembro
            month-=1;
            day = monthDays(month, year);
        }else if(day == 1 && month == 1){
            month = 12;
            day = monthDays(month, year);
            year-=1;
        }
    }
    public void set(int y , int m , int d){
        this.year =y;
        this.month = m;
        this.day = d;

    }
    public String toString(int day , int month , int year){
        return " ( "+year + " - " + month + " - " + day+" ) ";
    } 
    */

    public boolean validMonth(int month){
        if(month > 12 || month < 0){
            return false;
        }
        return true;
    }
    public int monthDays(int month , int year){
        int days = 0;
        if(leapYear(year) == true && month == 2){
            days = 29;
        }else if(leapYear(year) ==false && month == 2){
            days = 28;
        }else if(month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12){
            days =31 ;
        }else days = 30;
        return days;
    }
    public boolean leapYear(int year){
        if(year%4 == 0 && year%100 != 0 || year%400 == 0){
            return true;
        }
        return false;
    }
    public boolean valid(int day , int month , int year){
        if(year >= 0 && validMonth(month)== true && day>0 && day <= monthDays(month, year)){
            return true;
        }
        return false;
    }
}
