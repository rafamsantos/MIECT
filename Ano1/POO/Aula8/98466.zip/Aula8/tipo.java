package Aula8;

public enum tipo {
    desportivo , estrada;
}
