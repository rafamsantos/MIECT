package Aula8;

public interface KmPercorridosInterface {
    void trajeto(int kilometros);
    int ultimoTrajeto();
    int distanciaTotal();
}
