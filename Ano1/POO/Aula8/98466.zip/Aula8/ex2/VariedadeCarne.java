package Aula8.ex2;

public enum VariedadeCarne {
    VACA,PERU,PORCO,FRANGO,OUTRA
}
