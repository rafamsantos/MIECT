package Aula8.ex2;

public interface AlimentoVegetariano {
    
}
