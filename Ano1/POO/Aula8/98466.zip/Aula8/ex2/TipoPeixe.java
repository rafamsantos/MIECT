package Aula8.ex2;

public enum TipoPeixe {
    CONGELADO, FRESCO
}
