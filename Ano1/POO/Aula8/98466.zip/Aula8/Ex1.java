package Aula8;

public class Ex1 {
    public static void main(String[] args) {
        
    }
    
}
