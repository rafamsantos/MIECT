package Aula7.ex3;

public enum TipoQuarto {
    single , doubl , twin , triple
}
