package Aula7.ex3;

public class QuartoHotel {
    private TipoQuarto tq;
    
}
