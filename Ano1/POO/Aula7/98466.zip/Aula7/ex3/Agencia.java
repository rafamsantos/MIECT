package Aula7.ex3;

import java.util.LinkedList;

public class Agencia {
    private String nome;
    private String endereço;
    private LinkedList<Alojamento> aloj = new LinkedList<>();
    private LinkedList<Carro>carros = new LinkedList<>();
    
    public Agencia(){}

}
