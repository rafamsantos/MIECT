package Aula7.ex3;

public class Alojamento {
    private String codigo;
    private String nome;
    private String local;
    private double ppnoite;
    private boolean dispo;
    private double ava;
    
   
}
