package Aula7.ex3;

public class Carro {
    private char classe;
    private TipoMotorizacao tm;
    
}
