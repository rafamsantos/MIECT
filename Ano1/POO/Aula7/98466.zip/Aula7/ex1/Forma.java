package Aula7.ex1;

public abstract class Forma {
    public abstract double getPeri(double h , double l1 , double l2);
    public abstract double getArea(double h,double l1 ,double l2);

    
}
